package com.srtxcheats.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.srtxcheats.model.GameProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "srt_x_cheats_settings")

/**
 * DataStoreManager:
 * Persistent storage for SRT X CHEATS gaming utility.
 * Manages game profiles, hardware telemetry preferences, booster toggles,
 * visual HUD layout, and visual aim crosshairs.
 *
 * NOTE: All sensitivity, macro, and keymapping preferences have been removed.
 */
class DataStoreManager(private val context: Context) {

    companion object {
        private val KEY_SELECTED_PACKAGE = stringPreferencesKey("selected_package")
        private val KEY_SELECTED_APP_NAME = stringPreferencesKey("selected_app_name")
        private val KEY_OVERLAY_SCALE = floatPreferencesKey("overlay_scale")
        private val KEY_EXPANDED_MENU_SIZE = floatPreferencesKey("expanded_menu_size")
        private val KEY_OVERLAY_ALPHA = floatPreferencesKey("overlay_alpha")
        private val KEY_GLASS_TRANSPARENCY = floatPreferencesKey("glass_transparency")
        private val KEY_GLASS_BLUR = stringPreferencesKey("glass_blur")
        private val KEY_OVERLAY_POS_X = intPreferencesKey("overlay_pos_x")
        private val KEY_OVERLAY_POS_Y = intPreferencesKey("overlay_pos_y")

        // Restore Display
        private val KEY_RESTORE_DISPLAY_ENABLED = booleanPreferencesKey("restore_display_enabled")

        // Hardware HUD Telemetry Toggles
        private val KEY_SHOW_FPS = booleanPreferencesKey("show_fps")
        private val KEY_SHOW_FRAME_TIME = booleanPreferencesKey("show_frame_time")
        private val KEY_SHOW_CPU = booleanPreferencesKey("show_cpu")
        private val KEY_SHOW_CLOCK = booleanPreferencesKey("show_clock")
        private val KEY_SHOW_RAM = booleanPreferencesKey("show_ram")
        private val KEY_SHOW_TEMP = booleanPreferencesKey("show_temp")
        private val KEY_SHOW_BATTERY = booleanPreferencesKey("show_battery")
        private val KEY_SHOW_DISPLAY_HZ = booleanPreferencesKey("show_display_hz")
        private val KEY_SHOW_GRAPH = booleanPreferencesKey("show_graph")

        // Visual Aim Marker / Crosshair
        private val KEY_SHOW_CROSSHAIR = booleanPreferencesKey("show_crosshair")
        private val KEY_CROSSHAIR_STYLE = stringPreferencesKey("crosshair_style")
        private val KEY_CROSSHAIR_COLOR = longPreferencesKey("crosshair_color")
        private val KEY_CROSSHAIR_SIZE = intPreferencesKey("crosshair_size")
        private val KEY_CROSSHAIR_TRANSPARENCY = floatPreferencesKey("crosshair_transparency")
        private val KEY_CROSSHAIR_ROTATION = floatPreferencesKey("crosshair_rotation")
        private val KEY_CROSSHAIR_OFFSET_X = intPreferencesKey("crosshair_offset_x")
        private val KEY_CROSSHAIR_OFFSET_Y = intPreferencesKey("crosshair_offset_y")

        // Macro [E] Configuration
        private val KEY_MACRO_E_ENABLED = booleanPreferencesKey("macro_e_enabled")
        private val KEY_MACRO_E_SIZE = intPreferencesKey("macro_e_size")
        private val KEY_MACRO_E_TRANSPARENCY = floatPreferencesKey("macro_e_transparency")
        private val KEY_MACRO_E_POS_X = intPreferencesKey("macro_e_pos_x")
        private val KEY_MACRO_E_POS_Y = intPreferencesKey("macro_e_pos_y")
        private val KEY_MACRO_E_TARGET_X = intPreferencesKey("macro_e_target_x")
        private val KEY_MACRO_E_TARGET_Y = intPreferencesKey("macro_e_target_y")
        private val KEY_MACRO_E_TAP_SPEED = intPreferencesKey("macro_e_tap_speed")
        private val KEY_MACRO_E_RETAP_SPEED = intPreferencesKey("macro_e_retap_speed")
        private val KEY_MACRO_E_LOOP = booleanPreferencesKey("macro_e_loop")

        // Macro [G] Configuration
        private val KEY_MACRO_G_ENABLED = booleanPreferencesKey("macro_g_enabled")
        private val KEY_MACRO_G_SIZE = intPreferencesKey("macro_g_size")
        private val KEY_MACRO_G_TRANSPARENCY = floatPreferencesKey("macro_g_transparency")
        private val KEY_MACRO_G_POS_X = intPreferencesKey("macro_g_pos_x")
        private val KEY_MACRO_G_POS_Y = intPreferencesKey("macro_g_pos_y")
        private val KEY_MACRO_G_TARGET_X = intPreferencesKey("macro_g_target_x")
        private val KEY_MACRO_G_TARGET_Y = intPreferencesKey("macro_g_target_y")
        private val KEY_MACRO_G_TAP_SPEED = intPreferencesKey("macro_g_tap_speed")
        private val KEY_MACRO_G_RETAP_SPEED = intPreferencesKey("macro_g_retap_speed")
        private val KEY_MACRO_G_LOOP = booleanPreferencesKey("macro_g_loop")

        // Game Booster & System Optimizer
        private val KEY_RAM_BOOST_ACTIVE = booleanPreferencesKey("ram_boost_active")
        private val KEY_LAST_RAM_FREED_MB = longPreferencesKey("last_ram_freed_mb")
        private val KEY_GAME_BOOST_ACTIVE = booleanPreferencesKey("game_boost_active")
        private val KEY_GAMING_MODE_ACTIVE = booleanPreferencesKey("gaming_mode_active")
        private val KEY_PERFORMANCE_BOOST_ACTIVE = booleanPreferencesKey("performance_boost_active")
        private val KEY_SAMPLING_INTERVAL_MS = intPreferencesKey("sampling_interval_ms")

        // Helper to get package-specific key
        private fun pkgKey(pkg: String, base: String) = "${pkg.replace('.', '_')}_$base"
    }

    val selectedPackageFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
    }

    val selectedAppNameFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_SELECTED_APP_NAME] ?: "Free Fire MAX"
    }

    val overlayScaleFlow: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[KEY_OVERLAY_SCALE] ?: 1.0f
    }

    val expandedMenuSizeFlow: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[KEY_EXPANDED_MENU_SIZE] ?: 1.0f
    }

    val overlayAlphaFlow: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[KEY_OVERLAY_ALPHA] ?: 0.85f
    }

    val glassTransparencyFlow: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[KEY_GLASS_TRANSPARENCY] ?: 0.85f
    }

    val glassBlurFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_GLASS_BLUR] ?: "MEDIUM"
    }

    val overlayPositionFlow: Flow<Pair<Int, Int>> = context.dataStore.data.map { prefs ->
        Pair(prefs[KEY_OVERLAY_POS_X] ?: 50, prefs[KEY_OVERLAY_POS_Y] ?: 200)
    }

    val ramBoostActiveFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_RAM_BOOST_ACTIVE] ?: true
    }

    val gameBoostActiveFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_GAME_BOOST_ACTIVE] ?: false
    }

    val gamingModeActiveFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_GAMING_MODE_ACTIVE] ?: false
    }

    val performanceBoostActiveFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_PERFORMANCE_BOOST_ACTIVE] ?: false
    }

    val samplingIntervalMsFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_SAMPLING_INTERVAL_MS] ?: 1000
    }

    val gameProfileFlow: Flow<GameProfile> = context.dataStore.data.map { prefs ->
        val pkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
        val name = prefs[KEY_SELECTED_APP_NAME] ?: "Free Fire MAX"

        val pRamBoostKey = booleanPreferencesKey(pkgKey(pkg, "ram_boost"))
        val pGameBoostKey = booleanPreferencesKey(pkgKey(pkg, "game_boost"))
        val pGamingModeKey = booleanPreferencesKey(pkgKey(pkg, "gaming_mode"))
        val pPerfBoostKey = booleanPreferencesKey(pkgKey(pkg, "perf_boost"))
        val pScaleKey = floatPreferencesKey(pkgKey(pkg, "scale"))
        val pMenuSizeKey = floatPreferencesKey(pkgKey(pkg, "menu_size"))
        val pAlphaKey = floatPreferencesKey(pkgKey(pkg, "alpha"))
        val pMacroEEnabledKey = booleanPreferencesKey(pkgKey(pkg, "macro_e_enabled"))
        val pMacroESizeKey = intPreferencesKey(pkgKey(pkg, "macro_e_size"))
        val pMacroETransKey = floatPreferencesKey(pkgKey(pkg, "macro_e_trans"))
        val pMacroEPosXKey = intPreferencesKey(pkgKey(pkg, "macro_e_pos_x"))
        val pMacroEPosYKey = intPreferencesKey(pkgKey(pkg, "macro_e_pos_y"))
        val pMacroETargetXKey = intPreferencesKey(pkgKey(pkg, "macro_e_target_x"))
        val pMacroETargetYKey = intPreferencesKey(pkgKey(pkg, "macro_e_target_y"))
        val pMacroETapSpeedKey = intPreferencesKey(pkgKey(pkg, "macro_e_tap_speed"))
        val pMacroERetapSpeedKey = intPreferencesKey(pkgKey(pkg, "macro_e_retap_speed"))
        val pMacroELoopKey = booleanPreferencesKey(pkgKey(pkg, "macro_e_loop"))
        val pMacroGEnabledKey = booleanPreferencesKey(pkgKey(pkg, "macro_g_enabled"))
        val pMacroGSizeKey = intPreferencesKey(pkgKey(pkg, "macro_g_size"))
        val pMacroGTransKey = floatPreferencesKey(pkgKey(pkg, "macro_g_trans"))
        val pMacroGPosXKey = intPreferencesKey(pkgKey(pkg, "macro_g_pos_x"))
        val pMacroGPosYKey = intPreferencesKey(pkgKey(pkg, "macro_g_pos_y"))
        val pMacroGTargetXKey = intPreferencesKey(pkgKey(pkg, "macro_g_target_x"))
        val pMacroGTargetYKey = intPreferencesKey(pkgKey(pkg, "macro_g_target_y"))
        val pMacroGTapSpeedKey = intPreferencesKey(pkgKey(pkg, "macro_g_tap_speed"))
        val pMacroGRetapSpeedKey = intPreferencesKey(pkgKey(pkg, "macro_g_retap_speed"))
        val pMacroGLoopKey = booleanPreferencesKey(pkgKey(pkg, "macro_g_loop"))

        val ramBoost = prefs[pRamBoostKey] ?: (prefs[KEY_RAM_BOOST_ACTIVE] ?: true)
        val gameBoost = prefs[pGameBoostKey] ?: (prefs[KEY_GAME_BOOST_ACTIVE] ?: false)
        val gamingMode = prefs[pGamingModeKey] ?: (prefs[KEY_GAMING_MODE_ACTIVE] ?: false)
        val perfBoost = prefs[pPerfBoostKey] ?: (prefs[KEY_PERFORMANCE_BOOST_ACTIVE] ?: false)
        val scale = prefs[pScaleKey] ?: (prefs[KEY_OVERLAY_SCALE] ?: 1.0f)
        val menuSize = prefs[pMenuSizeKey] ?: (prefs[KEY_EXPANDED_MENU_SIZE] ?: 1.0f)
        val alpha = prefs[pAlphaKey] ?: (prefs[KEY_GLASS_TRANSPARENCY] ?: (prefs[KEY_OVERLAY_ALPHA] ?: 0.85f))
        val blur = prefs[KEY_GLASS_BLUR] ?: "MEDIUM"

        GameProfile(
            packageName = pkg,
            appName = name,
            isOverlayEnabled = true,
            restoreDisplayEnabled = prefs[KEY_RESTORE_DISPLAY_ENABLED] ?: true,
            showFps = prefs[KEY_SHOW_FPS] ?: true,
            showFrameTime = prefs[KEY_SHOW_FRAME_TIME] ?: true,
            showCpu = prefs[KEY_SHOW_CPU] ?: true,
            showClock = prefs[KEY_SHOW_CLOCK] ?: true,
            showRam = prefs[KEY_SHOW_RAM] ?: true,
            showTemp = prefs[KEY_SHOW_TEMP] ?: true,
            showBattery = prefs[KEY_SHOW_BATTERY] ?: true,
            showDisplayHz = prefs[KEY_SHOW_DISPLAY_HZ] ?: true,
            showGraph = prefs[KEY_SHOW_GRAPH] ?: false,
            showCrosshair = prefs[KEY_SHOW_CROSSHAIR] ?: false,
            crosshairStyle = prefs[KEY_CROSSHAIR_STYLE] ?: "CROSS",
            crosshairColor = prefs[KEY_CROSSHAIR_COLOR] ?: 0xFF00E5FF,
            crosshairSizeDp = prefs[KEY_CROSSHAIR_SIZE] ?: 24,
            crosshairTransparency = prefs[KEY_CROSSHAIR_TRANSPARENCY] ?: 1.0f,
            crosshairRotation = prefs[KEY_CROSSHAIR_ROTATION] ?: 0f,
            crosshairOffsetX = prefs[KEY_CROSSHAIR_OFFSET_X] ?: 0,
            crosshairOffsetY = prefs[KEY_CROSSHAIR_OFFSET_Y] ?: 0,
            macroEEnabled = prefs[pMacroEEnabledKey] ?: (prefs[KEY_MACRO_E_ENABLED] ?: false),
            macroESizeDp = prefs[pMacroESizeKey] ?: (prefs[KEY_MACRO_E_SIZE] ?: 48),
            macroETransparency = prefs[pMacroETransKey] ?: (prefs[KEY_MACRO_E_TRANSPARENCY] ?: 0.9f),
            macroEPosX = prefs[pMacroEPosXKey] ?: (prefs[KEY_MACRO_E_POS_X] ?: 120),
            macroEPosY = prefs[pMacroEPosYKey] ?: (prefs[KEY_MACRO_E_POS_Y] ?: 400),
            macroETargetX = prefs[pMacroETargetXKey] ?: (prefs[KEY_MACRO_E_TARGET_X] ?: 540),
            macroETargetY = prefs[pMacroETargetYKey] ?: (prefs[KEY_MACRO_E_TARGET_Y] ?: 960),
            macroETapSpeedMs = (prefs[pMacroETapSpeedKey] ?: (prefs[KEY_MACRO_E_TAP_SPEED] ?: 100)).coerceAtLeast(5),
            macroERetapSpeedMs = (prefs[pMacroERetapSpeedKey] ?: (prefs[KEY_MACRO_E_RETAP_SPEED] ?: 100)).coerceAtLeast(5),
            macroELoop = prefs[pMacroELoopKey] ?: (prefs[KEY_MACRO_E_LOOP] ?: false),
            macroGEnabled = prefs[pMacroGEnabledKey] ?: (prefs[KEY_MACRO_G_ENABLED] ?: false),
            macroGSizeDp = prefs[pMacroGSizeKey] ?: (prefs[KEY_MACRO_G_SIZE] ?: 56),
            macroGTransparency = prefs[pMacroGTransKey] ?: (prefs[KEY_MACRO_G_TRANSPARENCY] ?: 0.9f),
            macroGPosX = prefs[pMacroGPosXKey] ?: (prefs[KEY_MACRO_G_POS_X] ?: 120),
            macroGPosY = prefs[pMacroGPosYKey] ?: (prefs[KEY_MACRO_G_POS_Y] ?: 520),
            macroGTargetX = prefs[pMacroGTargetXKey] ?: (prefs[KEY_MACRO_G_TARGET_X] ?: 540),
            macroGTargetY = prefs[pMacroGTargetYKey] ?: (prefs[KEY_MACRO_G_TARGET_Y] ?: 1100),
            macroGTapSpeedMs = (prefs[pMacroGTapSpeedKey] ?: (prefs[KEY_MACRO_G_TAP_SPEED] ?: 100)).coerceAtLeast(5),
            macroGRetapSpeedMs = (prefs[pMacroGRetapSpeedKey] ?: (prefs[KEY_MACRO_G_RETAP_SPEED] ?: 100)).coerceAtLeast(5),
            macroGLoop = prefs[pMacroGLoopKey] ?: (prefs[KEY_MACRO_G_LOOP] ?: false),
            isRamBoostActive = ramBoost,
            lastRamFreedMb = prefs[KEY_LAST_RAM_FREED_MB] ?: 0L,
            isGameBoostActive = gameBoost,
            isGamingModeActive = gamingMode,
            isPerformanceBoostActive = perfBoost,
            overlayScale = scale,
            expandedMenuSize = menuSize,
            overlayAlpha = alpha,
            glassTransparency = alpha,
            glassBlur = blur,
            overlayPosX = prefs[KEY_OVERLAY_POS_X] ?: 50,
            overlayPosY = prefs[KEY_OVERLAY_POS_Y] ?: 200
        )
    }

    suspend fun saveSelectedGame(packageName: String, appName: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_SELECTED_PACKAGE] = packageName
            prefs[KEY_SELECTED_APP_NAME] = appName
        }
    }

    suspend fun saveGameProfile(profile: GameProfile) {
        context.dataStore.edit { prefs ->
            val pkg = profile.packageName
            prefs[KEY_SELECTED_PACKAGE] = pkg
            prefs[KEY_SELECTED_APP_NAME] = profile.appName

            prefs[booleanPreferencesKey(pkgKey(pkg, "ram_boost"))] = profile.isRamBoostActive
            prefs[booleanPreferencesKey(pkgKey(pkg, "game_boost"))] = profile.isGameBoostActive
            prefs[booleanPreferencesKey(pkgKey(pkg, "gaming_mode"))] = profile.isGamingModeActive
            prefs[booleanPreferencesKey(pkgKey(pkg, "perf_boost"))] = profile.isPerformanceBoostActive
            prefs[floatPreferencesKey(pkgKey(pkg, "scale"))] = profile.overlayScale
            prefs[floatPreferencesKey(pkgKey(pkg, "menu_size"))] = profile.expandedMenuSize
            prefs[floatPreferencesKey(pkgKey(pkg, "alpha"))] = profile.glassTransparency

            prefs[KEY_RESTORE_DISPLAY_ENABLED] = profile.restoreDisplayEnabled
            prefs[KEY_RAM_BOOST_ACTIVE] = profile.isRamBoostActive
            prefs[KEY_GAME_BOOST_ACTIVE] = profile.isGameBoostActive
            prefs[KEY_GAMING_MODE_ACTIVE] = profile.isGamingModeActive
            prefs[KEY_PERFORMANCE_BOOST_ACTIVE] = profile.isPerformanceBoostActive
            prefs[KEY_OVERLAY_SCALE] = profile.overlayScale
            prefs[KEY_EXPANDED_MENU_SIZE] = profile.expandedMenuSize
            prefs[KEY_OVERLAY_ALPHA] = profile.overlayAlpha
            prefs[KEY_GLASS_TRANSPARENCY] = profile.glassTransparency
            prefs[KEY_GLASS_BLUR] = profile.glassBlur
            prefs[KEY_SHOW_FPS] = profile.showFps
            prefs[KEY_SHOW_FRAME_TIME] = profile.showFrameTime
            prefs[KEY_SHOW_CPU] = profile.showCpu
            prefs[KEY_SHOW_CLOCK] = profile.showClock
            prefs[KEY_SHOW_RAM] = profile.showRam
            prefs[KEY_SHOW_TEMP] = profile.showTemp
            prefs[KEY_SHOW_BATTERY] = profile.showBattery
            prefs[KEY_SHOW_DISPLAY_HZ] = profile.showDisplayHz
            prefs[KEY_SHOW_GRAPH] = profile.showGraph
            prefs[KEY_SHOW_CROSSHAIR] = profile.showCrosshair
            prefs[KEY_CROSSHAIR_STYLE] = profile.crosshairStyle
            prefs[KEY_CROSSHAIR_COLOR] = profile.crosshairColor
            prefs[KEY_CROSSHAIR_SIZE] = profile.crosshairSizeDp
            prefs[KEY_CROSSHAIR_TRANSPARENCY] = profile.crosshairTransparency
            prefs[KEY_CROSSHAIR_ROTATION] = profile.crosshairRotation
            prefs[KEY_CROSSHAIR_OFFSET_X] = profile.crosshairOffsetX
            prefs[KEY_CROSSHAIR_OFFSET_Y] = profile.crosshairOffsetY

            prefs[KEY_MACRO_E_ENABLED] = profile.macroEEnabled
            prefs[KEY_MACRO_E_SIZE] = profile.macroESizeDp
            prefs[KEY_MACRO_E_TRANSPARENCY] = profile.macroETransparency
            prefs[KEY_MACRO_E_POS_X] = profile.macroEPosX
            prefs[KEY_MACRO_E_POS_Y] = profile.macroEPosY
            prefs[KEY_MACRO_E_TARGET_X] = profile.macroETargetX
            prefs[KEY_MACRO_E_TARGET_Y] = profile.macroETargetY
            prefs[KEY_MACRO_E_TAP_SPEED] = profile.macroETapSpeedMs
            prefs[KEY_MACRO_E_RETAP_SPEED] = profile.macroERetapSpeedMs
            prefs[KEY_MACRO_E_LOOP] = profile.macroELoop

            prefs[booleanPreferencesKey(pkgKey(pkg, "macro_e_enabled"))] = profile.macroEEnabled
            prefs[intPreferencesKey(pkgKey(pkg, "macro_e_size"))] = profile.macroESizeDp
            prefs[floatPreferencesKey(pkgKey(pkg, "macro_e_trans"))] = profile.macroETransparency
            prefs[intPreferencesKey(pkgKey(pkg, "macro_e_pos_x"))] = profile.macroEPosX
            prefs[intPreferencesKey(pkgKey(pkg, "macro_e_pos_y"))] = profile.macroEPosY
            prefs[intPreferencesKey(pkgKey(pkg, "macro_e_target_x"))] = profile.macroETargetX
            prefs[intPreferencesKey(pkgKey(pkg, "macro_e_target_y"))] = profile.macroETargetY
            prefs[intPreferencesKey(pkgKey(pkg, "macro_e_tap_speed"))] = profile.macroETapSpeedMs
            prefs[intPreferencesKey(pkgKey(pkg, "macro_e_retap_speed"))] = profile.macroERetapSpeedMs
            prefs[booleanPreferencesKey(pkgKey(pkg, "macro_e_loop"))] = profile.macroELoop

            prefs[KEY_MACRO_G_ENABLED] = profile.macroGEnabled
            prefs[KEY_MACRO_G_SIZE] = profile.macroGSizeDp
            prefs[KEY_MACRO_G_TRANSPARENCY] = profile.macroGTransparency
            prefs[KEY_MACRO_G_POS_X] = profile.macroGPosX
            prefs[KEY_MACRO_G_POS_Y] = profile.macroGPosY
            prefs[KEY_MACRO_G_TARGET_X] = profile.macroGTargetX
            prefs[KEY_MACRO_G_TARGET_Y] = profile.macroGTargetY
            prefs[KEY_MACRO_G_TAP_SPEED] = profile.macroGTapSpeedMs
            prefs[KEY_MACRO_G_RETAP_SPEED] = profile.macroGRetapSpeedMs
            prefs[KEY_MACRO_G_LOOP] = profile.macroGLoop

            prefs[booleanPreferencesKey(pkgKey(pkg, "macro_g_enabled"))] = profile.macroGEnabled
            prefs[intPreferencesKey(pkgKey(pkg, "macro_g_size"))] = profile.macroGSizeDp
            prefs[floatPreferencesKey(pkgKey(pkg, "macro_g_trans"))] = profile.macroGTransparency
            prefs[intPreferencesKey(pkgKey(pkg, "macro_g_pos_x"))] = profile.macroGPosX
            prefs[intPreferencesKey(pkgKey(pkg, "macro_g_pos_y"))] = profile.macroGPosY
            prefs[intPreferencesKey(pkgKey(pkg, "macro_g_target_x"))] = profile.macroGTargetX
            prefs[intPreferencesKey(pkgKey(pkg, "macro_g_target_y"))] = profile.macroGTargetY
            prefs[intPreferencesKey(pkgKey(pkg, "macro_g_tap_speed"))] = profile.macroGTapSpeedMs
            prefs[intPreferencesKey(pkgKey(pkg, "macro_g_retap_speed"))] = profile.macroGRetapSpeedMs
            prefs[booleanPreferencesKey(pkgKey(pkg, "macro_g_loop"))] = profile.macroGLoop
        }
    }

    suspend fun saveOverlayCustomization(scale: Float, alpha: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_OVERLAY_SCALE] = scale
            prefs[KEY_OVERLAY_ALPHA] = alpha
            prefs[KEY_GLASS_TRANSPARENCY] = alpha
        }
    }

    suspend fun saveOverlayPosition(x: Int, y: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_OVERLAY_POS_X] = x
            prefs[KEY_OVERLAY_POS_Y] = y
        }
    }

    suspend fun saveLastRamFreedMb(freedMb: Long) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_RAM_FREED_MB] = freedMb
        }
    }

    suspend fun setRamBoostActive(active: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_RAM_BOOST_ACTIVE] = active
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[booleanPreferencesKey(pkgKey(currentPkg, "ram_boost"))] = active
        }
    }

    suspend fun setGameBoostActive(active: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_GAME_BOOST_ACTIVE] = active
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[booleanPreferencesKey(pkgKey(currentPkg, "game_boost"))] = active
        }
    }

    suspend fun setGamingModeActive(active: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_GAMING_MODE_ACTIVE] = active
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[booleanPreferencesKey(pkgKey(currentPkg, "gaming_mode"))] = active
        }
    }

    suspend fun setPerformanceBoostActive(active: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_PERFORMANCE_BOOST_ACTIVE] = active
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[booleanPreferencesKey(pkgKey(currentPkg, "perf_boost"))] = active
        }
    }

    suspend fun updateMetricToggle(metric: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            when (metric) {
                "fps" -> prefs[KEY_SHOW_FPS] = enabled
                "frame_time" -> prefs[KEY_SHOW_FRAME_TIME] = enabled
                "cpu" -> prefs[KEY_SHOW_CPU] = enabled
                "clock" -> prefs[KEY_SHOW_CLOCK] = enabled
                "ram" -> prefs[KEY_SHOW_RAM] = enabled
                "temp" -> prefs[KEY_SHOW_TEMP] = enabled
                "battery" -> prefs[KEY_SHOW_BATTERY] = enabled
                "display" -> prefs[KEY_SHOW_DISPLAY_HZ] = enabled
                "graph" -> prefs[KEY_SHOW_GRAPH] = enabled
                "crosshair" -> prefs[KEY_SHOW_CROSSHAIR] = enabled
            }
        }
    }

    suspend fun updateCrosshairSettings(style: String, color: Long, sizeDp: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_STYLE] = style
            prefs[KEY_CROSSHAIR_COLOR] = color
            prefs[KEY_CROSSHAIR_SIZE] = sizeDp
        }
    }

    suspend fun saveCrosshairOffset(offsetX: Int, offsetY: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_OFFSET_X] = offsetX
            prefs[KEY_CROSSHAIR_OFFSET_Y] = offsetY
        }
    }

    suspend fun saveOverlayScale(scale: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_OVERLAY_SCALE] = scale
        }
    }

    suspend fun saveExpandedMenuSize(size: Float) {
        context.dataStore.edit { prefs ->
            val s = size.coerceIn(0.1f, 2.0f)
            prefs[KEY_EXPANDED_MENU_SIZE] = s
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[floatPreferencesKey(pkgKey(currentPkg, "menu_size"))] = s
        }
    }

    suspend fun saveOverlayAlpha(alpha: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_OVERLAY_ALPHA] = alpha
        }
    }

    suspend fun saveGlassTransparency(transparency: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_GLASS_TRANSPARENCY] = transparency
        }
    }

    suspend fun saveGlassBlur(blurMode: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_GLASS_BLUR] = blurMode
        }
    }

    suspend fun saveCrosshairSettings(style: String, color: Long) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_STYLE] = style
            prefs[KEY_CROSSHAIR_COLOR] = color
        }
    }

    suspend fun saveCrosshairSize(sizeDp: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_SIZE] = sizeDp
        }
    }

    suspend fun saveCrosshairStyle(style: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_STYLE] = style
        }
    }

    suspend fun saveAimMarkerPosition(x: Float, y: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_OFFSET_X] = x.toInt()
            prefs[KEY_CROSSHAIR_OFFSET_Y] = y.toInt()
        }
    }

    suspend fun saveRestoreDisplay(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_RESTORE_DISPLAY_ENABLED] = enabled
        }
    }

    suspend fun saveCrosshairTransparency(transparency: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_TRANSPARENCY] = transparency.coerceIn(0f, 1f)
        }
    }

    suspend fun saveCrosshairRotation(rotation: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_ROTATION] = rotation
        }
    }

    suspend fun updateCrosshairFull(
        style: String,
        color: Long,
        sizeDp: Int,
        transparency: Float,
        rotation: Float
    ) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CROSSHAIR_STYLE] = style
            prefs[KEY_CROSSHAIR_COLOR] = color
            prefs[KEY_CROSSHAIR_SIZE] = sizeDp
            prefs[KEY_CROSSHAIR_TRANSPARENCY] = transparency.coerceIn(0f, 1f)
            prefs[KEY_CROSSHAIR_ROTATION] = rotation
        }
    }

    // --- Macro [E] Setters ---
    suspend fun setMacroEEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MACRO_E_ENABLED] = enabled
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[booleanPreferencesKey(pkgKey(currentPkg, "macro_e_enabled"))] = enabled
        }
    }

    suspend fun saveMacroESize(sizeDp: Int) {
        context.dataStore.edit { prefs ->
            val s = sizeDp.coerceIn(24, 100)
            prefs[KEY_MACRO_E_SIZE] = s
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_e_size"))] = s
        }
    }

    suspend fun saveMacroETransparency(transparency: Float) {
        context.dataStore.edit { prefs ->
            val t = transparency.coerceIn(0f, 1f)
            prefs[KEY_MACRO_E_TRANSPARENCY] = t
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[floatPreferencesKey(pkgKey(currentPkg, "macro_e_trans"))] = t
        }
    }

    suspend fun saveMacroEPosition(x: Int, y: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MACRO_E_POS_X] = x
            prefs[KEY_MACRO_E_POS_Y] = y
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_e_pos_x"))] = x
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_e_pos_y"))] = y
        }
    }

    suspend fun saveMacroETarget(x: Int, y: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MACRO_E_TARGET_X] = x
            prefs[KEY_MACRO_E_TARGET_Y] = y
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_e_target_x"))] = x
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_e_target_y"))] = y
        }
    }

    suspend fun saveMacroETiming(tapSpeedMs: Int, retapSpeedMs: Int, loop: Boolean) {
        context.dataStore.edit { prefs ->
            val tap = tapSpeedMs.coerceAtLeast(5)
            val retap = retapSpeedMs.coerceAtLeast(5)
            prefs[KEY_MACRO_E_TAP_SPEED] = tap
            prefs[KEY_MACRO_E_RETAP_SPEED] = retap
            prefs[KEY_MACRO_E_LOOP] = loop
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_e_tap_speed"))] = tap
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_e_retap_speed"))] = retap
            prefs[booleanPreferencesKey(pkgKey(currentPkg, "macro_e_loop"))] = loop
        }
    }

    // --- Macro [G] Setters ---
    suspend fun setMacroGEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MACRO_G_ENABLED] = enabled
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[booleanPreferencesKey(pkgKey(currentPkg, "macro_g_enabled"))] = enabled
        }
    }

    suspend fun saveMacroGSize(sizeDp: Int) {
        context.dataStore.edit { prefs ->
            val s = sizeDp.coerceIn(24, 120)
            prefs[KEY_MACRO_G_SIZE] = s
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_g_size"))] = s
        }
    }

    suspend fun saveMacroGTransparency(transparency: Float) {
        context.dataStore.edit { prefs ->
            val t = transparency.coerceIn(0f, 1f)
            prefs[KEY_MACRO_G_TRANSPARENCY] = t
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[floatPreferencesKey(pkgKey(currentPkg, "macro_g_trans"))] = t
        }
    }

    suspend fun saveMacroGPosition(x: Int, y: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MACRO_G_POS_X] = x
            prefs[KEY_MACRO_G_POS_Y] = y
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_g_pos_x"))] = x
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_g_pos_y"))] = y
        }
    }

    suspend fun saveMacroGTarget(x: Int, y: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MACRO_G_TARGET_X] = x
            prefs[KEY_MACRO_G_TARGET_Y] = y
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_g_target_x"))] = x
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_g_target_y"))] = y
        }
    }

    suspend fun saveMacroGTiming(tapSpeedMs: Int, retapSpeedMs: Int, loop: Boolean) {
        context.dataStore.edit { prefs ->
            val tap = tapSpeedMs.coerceAtLeast(5)
            val retap = retapSpeedMs.coerceAtLeast(5)
            prefs[KEY_MACRO_G_TAP_SPEED] = tap
            prefs[KEY_MACRO_G_RETAP_SPEED] = retap
            prefs[KEY_MACRO_G_LOOP] = loop
            val currentPkg = prefs[KEY_SELECTED_PACKAGE] ?: GameProfile.FREE_FIRE_MAX_PACKAGE
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_g_tap_speed"))] = tap
            prefs[intPreferencesKey(pkgKey(currentPkg, "macro_g_retap_speed"))] = retap
            prefs[booleanPreferencesKey(pkgKey(currentPkg, "macro_g_loop"))] = loop
        }
    }

    suspend fun resetToDefaults() {
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
    }

    suspend fun setSamplingInterval(ms: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_SAMPLING_INTERVAL_MS] = ms
        }
    }
}
