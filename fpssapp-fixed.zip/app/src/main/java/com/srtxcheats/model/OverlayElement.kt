package com.srtxcheats.model

/**
 * Supported overlay element types in SRT X CHEATS.
 */
enum class OverlayElementType {
    AIM_MARKER,
    STATS_BADGE,
    POWER_HUD
}

/**
 * Unified shared overlay model.
 * All positions and dimensions are persisted in DataStore and can be edited
 * concurrently during Key Mapping mode.
 */
data class OverlayElement(
    val id: String,
    val type: OverlayElementType,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val enabled: Boolean,
    val opacity: Float
)
