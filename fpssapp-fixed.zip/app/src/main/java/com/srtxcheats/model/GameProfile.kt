package com.srtxcheats.model

/**
 * GameProfile:
 * Represents the configuration and active gaming utilities for a specific title.
 * Focuses on real hardware telemetry, visual HUD overlays, system memory optimization,
 * display utilities, visual aim crosshairs, and configurable touch macro buttons.
 */
data class GameProfile(
    val packageName: String,
    val appName: String,
    val isOverlayEnabled: Boolean = true,
    // Restore Display state
    val restoreDisplayEnabled: Boolean = true,
    // Real Hardware HUD Telemetry
    val showFps: Boolean = true,
    val showFrameTime: Boolean = true,
    val showCpu: Boolean = true,
    val showRam: Boolean = true,
    val showTemp: Boolean = true,
    val showBattery: Boolean = true,
    val showClock: Boolean = true,
    val showDisplayHz: Boolean = true,
    val showGraph: Boolean = false,
    // Visual Aim Marker / Crosshair (Expanded with 15 styles, rotation, alpha)
    val showCrosshair: Boolean = false,
    val crosshairStyle: String = "CROSS",
    val crosshairColor: Long = 0xFF00E5FF, // Neon Cyan default
    val crosshairSizeDp: Int = 24,
    val crosshairTransparency: Float = 1.0f,
    val crosshairRotation: Float = 0f,
    val crosshairOffsetX: Int = 0,
    val crosshairOffsetY: Int = 0,
    // Macro [E] Configuration
    val macroEEnabled: Boolean = false,
    val macroESizeDp: Int = 48,
    val macroETransparency: Float = 0.9f,
    val macroEPosX: Int = 120,
    val macroEPosY: Int = 400,
    val macroETargetX: Int = 540,
    val macroETargetY: Int = 960,
    val macroETapSpeedMs: Int = 100,
    val macroERetapSpeedMs: Int = 100,
    val macroELoop: Boolean = false,
    // Macro [G] Configuration
    val macroGEnabled: Boolean = false,
    val macroGSizeDp: Int = 56,
    val macroGTransparency: Float = 0.9f,
    val macroGPosX: Int = 120,
    val macroGPosY: Int = 520,
    val macroGTargetX: Int = 540,
    val macroGTargetY: Int = 1100,
    val macroGTapSpeedMs: Int = 100,
    val macroGRetapSpeedMs: Int = 100,
    val macroGLoop: Boolean = false,
    // System Performance & Game Booster
    val isRamBoostActive: Boolean = true,
    val lastRamFreedMb: Long = 0L,
    val isGameBoostActive: Boolean = false,
    val isGamingModeActive: Boolean = false,
    val isPerformanceBoostActive: Boolean = false,
    // HUD Liquid Glass Customization
    val overlayScale: Float = 1.0f,
    val expandedMenuSize: Float = 1.0f,
    val overlayAlpha: Float = 0.85f,
    val glassTransparency: Float = 0.85f,
    val glassBlur: String = "MEDIUM", // OFF, LOW, MEDIUM, HIGH
    val overlayPosX: Int = 50,
    val overlayPosY: Int = 200
) {
    companion object {
        const val FREE_FIRE_PACKAGE = "com.dts.freefireth"
        const val FREE_FIRE_MAX_PACKAGE = "com.dts.freefiremax"

        fun defaultFor(pkg: String, name: String): GameProfile {
            return GameProfile(
                packageName = pkg,
                appName = name,
                isOverlayEnabled = true,
                restoreDisplayEnabled = true,
                showFps = true,
                showFrameTime = true,
                showCpu = true,
                showRam = true,
                showTemp = true,
                showBattery = true,
                showClock = true,
                showDisplayHz = true,
                showGraph = false,
                showCrosshair = false,
                crosshairStyle = "CROSS",
                crosshairColor = 0xFF00E5FF,
                crosshairSizeDp = 24,
                crosshairTransparency = 1.0f,
                crosshairRotation = 0f,
                crosshairOffsetX = 0,
                crosshairOffsetY = 0,
                macroEEnabled = false,
                macroESizeDp = 48,
                macroETransparency = 0.9f,
                macroEPosX = 120,
                macroEPosY = 400,
                macroETargetX = 540,
                macroETargetY = 960,
                macroETapSpeedMs = 100,
                macroERetapSpeedMs = 100,
                macroELoop = false,
                macroGEnabled = false,
                macroGSizeDp = 56,
                macroGTransparency = 0.9f,
                macroGPosX = 120,
                macroGPosY = 520,
                macroGTargetX = 540,
                macroGTargetY = 1100,
                macroGTapSpeedMs = 100,
                macroGRetapSpeedMs = 100,
                macroGLoop = false,
                isRamBoostActive = true,
                lastRamFreedMb = 0L,
                isGameBoostActive = false,
                isGamingModeActive = false,
                isPerformanceBoostActive = false,
                overlayScale = 1.0f,
                expandedMenuSize = 1.0f,
                overlayAlpha = 0.85f,
                glassTransparency = 0.85f,
                glassBlur = "MEDIUM",
                overlayPosX = 50,
                overlayPosY = 200
            )
        }
    }
}
