package com.srtxcheats.ui.overlay

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.srtxcheats.model.DeviceMetrics
import com.srtxcheats.model.GameProfile
import com.srtxcheats.ui.components.DirectionalPositionController
import com.srtxcheats.ui.theme.GamingAmber
import com.srtxcheats.ui.theme.GamingGreen
import com.srtxcheats.ui.theme.NeonCyan
import com.srtxcheats.ui.theme.NeonPurple
import com.srtxcheats.ui.theme.TextMuted
import com.srtxcheats.ui.theme.TextPrimary
import com.srtxcheats.ui.theme.TextSecondary

/**
 * Floating Gaming Overlay for SRT X CHEATS.
 *
 * Requirements:
 * 1. Collapsed Mode: ONLY SRT X CHEATS logo + FPS. No CPU, no extra buttons.
 * 2. Expanded Mode: Full responsive menu with dynamic size slider, transparency,
 *    Memory Clean, Game Boost, Aim Cursor, and Macro [E] & [G] press-and-hold settings.
 * 3. No target circles displayed over game.
 */
@Composable
fun FloatingOverlayContent(
    metrics: DeviceMetrics,
    profile: GameProfile,
    logoBitmap: Bitmap?,
    isExpanded: Boolean,
    keyDurationText: String = "ACTIVE",
    onToggleExpand: () -> Unit = {},
    onDragDelta: (dx: Float, dy: Float) -> Unit = { _, _ -> },
    onRestoreDisplayToggle: (Boolean) -> Unit = {},
    onForceRestoreAll: () -> Unit = {},
    onUpdateCrosshairOffset: (x: Int, y: Int) -> Unit = { _, _ -> },
    onUpdateCrosshairSize: (size: Int) -> Unit = {},
    onUpdateCrosshairStyle: (style: String) -> Unit = {},
    onUpdateCrosshairColor: (color: Long) -> Unit = {},
    onUpdateCrosshairTransparency: (Float) -> Unit = {},
    onUpdateCrosshairRotation: (Float) -> Unit = {},
    onPerformRamClean: () -> Unit = {},
    onPerformGameBoost: () -> Unit = {},
    onToggleMetric: (String) -> Unit = {},
    onToggleGraph: () -> Unit = {},
    onToggleCrosshair: () -> Unit = {},
    onToggleMacroE: (Boolean) -> Unit = {},
    onUpdateMacroESize: (Int) -> Unit = {},
    onUpdateMacroETransparency: (Float) -> Unit = {},
    onUpdateMacroEButtonPos: (Int, Int) -> Unit = { _, _ -> },
    onUpdateMacroETargetPos: (Int, Int) -> Unit = { _, _ -> },
    onUpdateMacroEInterval: (Int) -> Unit = {},
    onToggleMacroG: (Boolean) -> Unit = {},
    onUpdateMacroGSize: (Int) -> Unit = {},
    onUpdateMacroGTransparency: (Float) -> Unit = {},
    onUpdateMacroGButtonPos: (Int, Int) -> Unit = { _, _ -> },
    onUpdateMacroGTargetPos: (Int, Int) -> Unit = { _, _ -> },
    onUpdateMacroGInterval: (Int) -> Unit = {},
    onUpdateMenuSize: (Float) -> Unit = {},
    onUpdateTransparency: (Float) -> Unit = {},
    onOpenApp: () -> Unit = {},
    onCloseOverlay: () -> Unit = {}
) {
    if (isExpanded) {
        GamingPowerCenterMenu(
            metrics = metrics,
            profile = profile,
            logoBitmap = logoBitmap,
            keyDurationText = keyDurationText,
            onCollapse = onToggleExpand,
            onDragDelta = onDragDelta,
            onRestoreDisplayToggle = onRestoreDisplayToggle,
            onForceRestoreAll = onForceRestoreAll,
            onPerformRamClean = onPerformRamClean,
            onPerformGameBoost = onPerformGameBoost,
            onToggleCrosshair = onToggleCrosshair,
            onUpdateCrosshairSize = onUpdateCrosshairSize,
            onUpdateCrosshairStyle = onUpdateCrosshairStyle,
            onUpdateCrosshairColor = onUpdateCrosshairColor,
            onUpdateCrosshairTransparency = onUpdateCrosshairTransparency,
            onUpdateCrosshairRotation = onUpdateCrosshairRotation,
            onUpdateCrosshairOffset = onUpdateCrosshairOffset,
            onToggleMacroE = onToggleMacroE,
            onUpdateMacroESize = onUpdateMacroESize,
            onUpdateMacroETransparency = onUpdateMacroETransparency,
            onUpdateMacroEButtonPos = onUpdateMacroEButtonPos,
            onUpdateMacroETargetPos = onUpdateMacroETargetPos,
            onUpdateMacroEInterval = onUpdateMacroEInterval,
            onToggleMacroG = onToggleMacroG,
            onUpdateMacroGSize = onUpdateMacroGSize,
            onUpdateMacroGTransparency = onUpdateMacroGTransparency,
            onUpdateMacroGButtonPos = onUpdateMacroGButtonPos,
            onUpdateMacroGTargetPos = onUpdateMacroGTargetPos,
            onUpdateMacroGInterval = onUpdateMacroGInterval,
            onUpdateMenuSize = onUpdateMenuSize,
            onUpdateTransparency = onUpdateTransparency,
            onOpenApp = onOpenApp,
            onCloseOverlay = onCloseOverlay
        )
    } else {
        CompactFloatingBadge(
            metrics = metrics,
            logoBitmap = logoBitmap,
            onExpand = onToggleExpand,
            onDragDelta = onDragDelta
        )
    }
}

/**
 * Requirement 11:
 * COLLAPSED MODE:
 * Show ONLY:
 * SRT X CHEATS logo + FPS
 * Do NOT show CPU. Do NOT show extra buttons. Do NOT show extra metrics.
 */
@Composable
fun CompactFloatingBadge(
    metrics: DeviceMetrics,
    logoBitmap: Bitmap?,
    onExpand: () -> Unit,
    onDragDelta: (dx: Float, dy: Float) -> Unit
) {
    Surface(
        modifier = Modifier
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            }
            .clip(RoundedCornerShape(20.dp))
            .clickable { onExpand() }
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(
                    listOf(
                        NeonCyan.copy(alpha = 0.9f),
                        NeonPurple.copy(alpha = 0.7f),
                        NeonCyan.copy(alpha = 0.9f)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .testTag("floating_compact_badge"),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xF0050812),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (logoBitmap != null) {
                Image(
                    bitmap = logoBitmap.asImageBitmap(),
                    contentDescription = "SRT Logo",
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(GamingGreen)
                )
            }

            val fpsVal = metrics.fps ?: 60
            Text(
                text = "$fpsVal FPS",
                color = if (fpsVal >= 55) GamingGreen else if (fpsVal >= 30) GamingAmber else Color(0xFFFF5252),
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

/**
 * Large Floating Power Center:
 * Real responsive resizing via expandedMenuSize slider, real transparency,
 * prominent MEMORY CLEAN and GAME BOOST buttons, and complete macro/aim settings.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GamingPowerCenterMenu(
    metrics: DeviceMetrics,
    profile: GameProfile,
    logoBitmap: Bitmap?,
    keyDurationText: String,
    onCollapse: () -> Unit,
    onDragDelta: (dx: Float, dy: Float) -> Unit,
    onRestoreDisplayToggle: (Boolean) -> Unit,
    onForceRestoreAll: () -> Unit,
    onPerformRamClean: () -> Unit,
    onPerformGameBoost: () -> Unit,
    onToggleCrosshair: () -> Unit,
    onUpdateCrosshairSize: (Int) -> Unit,
    onUpdateCrosshairStyle: (String) -> Unit,
    onUpdateCrosshairColor: (Long) -> Unit,
    onUpdateCrosshairTransparency: (Float) -> Unit,
    onUpdateCrosshairRotation: (Float) -> Unit,
    onUpdateCrosshairOffset: (Int, Int) -> Unit,
    onToggleMacroE: (Boolean) -> Unit,
    onUpdateMacroESize: (Int) -> Unit,
    onUpdateMacroETransparency: (Float) -> Unit,
    onUpdateMacroEButtonPos: (Int, Int) -> Unit,
    onUpdateMacroETargetPos: (Int, Int) -> Unit,
    onUpdateMacroEInterval: (Int) -> Unit,
    onToggleMacroG: (Boolean) -> Unit,
    onUpdateMacroGSize: (Int) -> Unit,
    onUpdateMacroGTransparency: (Float) -> Unit,
    onUpdateMacroGButtonPos: (Int, Int) -> Unit,
    onUpdateMacroGTargetPos: (Int, Int) -> Unit,
    onUpdateMacroGInterval: (Int) -> Unit,
    onUpdateMenuSize: (Float) -> Unit,
    onUpdateTransparency: (Float) -> Unit,
    onOpenApp: () -> Unit,
    onCloseOverlay: () -> Unit
) {
    // Requirement 12 & 13: Size slider and transparency slider actually affect UI
    val menuScale = profile.expandedMenuSize.coerceIn(0.65f, 1.5f)
    val alpha = profile.overlayAlpha.coerceIn(0.2f, 1.0f)
    val menuWidth = (330 * menuScale).dp
    val menuMaxHeight = (490 * menuScale).dp

    var isAimSectionOpen by remember { mutableStateOf(false) }
    var isMacroESectionOpen by remember { mutableStateOf(false) }
    var isMacroGSectionOpen by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier
            .width(menuWidth)
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.2.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        NeonCyan.copy(alpha = 0.85f),
                        NeonPurple.copy(alpha = 0.4f),
                        Color(0x22FFFFFF),
                        NeonCyan.copy(alpha = 0.7f)
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("gaming_power_center_menu"),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xF0060914).copy(alpha = alpha),
        shadowElevation = 12.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {

            // Header & Drag Handle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onDragDelta(dragAmount.x, dragAmount.y)
                        }
                    }
                    .background(Color(0x2200E5FF))
                    .padding(horizontal = (12 * menuScale).dp, vertical = (6 * menuScale).dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (logoBitmap != null) {
                        Image(
                            bitmap = logoBitmap.asImageBitmap(),
                            contentDescription = "SRT Logo",
                            modifier = Modifier
                                .size((22 * menuScale).dp)
                                .clip(CircleShape)
                        )
                    }
                    Column {
                        Text(
                            text = "SRT X OVERLAY",
                            color = NeonCyan,
                            fontSize = (11 * menuScale).sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = keyDurationText,
                            color = GamingGreen,
                            fontSize = (8 * menuScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onCollapse,
                        modifier = Modifier.size((24 * menuScale).dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExpandLess,
                            contentDescription = "Minimize",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onCloseOverlay,
                        modifier = Modifier.size((24 * menuScale).dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFFFF5252)
                        )
                    }
                }
            }

            // Scrollable Menu Body
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = menuMaxHeight)
                    .verticalScroll(rememberScrollState())
                    .padding((10 * menuScale).dp),
                verticalArrangement = Arrangement.spacedBy((8 * menuScale).dp)
            ) {
                // Game Info & FPS
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x33101B2E),
                    border = BorderStroke(0.8.dp, Color(0x4400E5FF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Gamepad, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Column {
                                Text(
                                    text = profile.appName.ifBlank { "Gaming Hub" },
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = profile.packageName.ifBlank { "Universal Mode" },
                                    color = TextMuted,
                                    fontSize = 8.sp
                                )
                            }
                        }

                        val centerFps = metrics.fps ?: 0
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (centerFps > 0) Color(0x3300E676) else Color(0x33FFB300),
                            border = BorderStroke(0.6.dp, if (centerFps > 0) GamingGreen else GamingAmber)
                        ) {
                            Text(
                                text = if (centerFps > 0) "$centerFps FPS" else "FPS N/A",
                                color = if (centerFps > 0) GamingGreen else GamingAmber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Telemetry Metrics Grid
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x22050B14),
                    border = BorderStroke(0.6.dp, Color(0x22FFFFFF))
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("CPU: ${metrics.cpuUsagePercent ?: 0}%", color = NeonCyan, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                            Text("RAM: ${metrics.ramUsedGb} GB", color = GamingGreen, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                            Text("TEMP: ${metrics.batteryTempC ?: 0f}°C", color = GamingAmber, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                // PROMINENT MEMORY CLEAN AND GAME BOOST BUTTONS
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // MEMORY CLEAN
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onPerformRamClean() },
                        color = Color(0x3300E676),
                        border = BorderStroke(1.dp, GamingGreen),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null, tint = GamingGreen, modifier = Modifier.size(18.dp))
                            Text("MEMORY CLEAN", color = GamingGreen, fontSize = 9.sp, fontWeight = FontWeight.Black)
                            Text("Reclaim RAM", color = TextSecondary, fontSize = 7.5.sp)
                        }
                    }

                    // GAME BOOST
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onPerformGameBoost() },
                        color = Color(0x3300E5FF),
                        border = BorderStroke(1.dp, NeonCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                            Text("GAME BOOST", color = NeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Black)
                            Text("Close background apps", color = TextSecondary, fontSize = 7.5.sp)
                        }
                    }
                }

                // RESTORE DISPLAY SECTION
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x2213233A),
                    border = BorderStroke(0.8.dp, Color(0x4400E5FF))
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Restore, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(15.dp))
                                Text("RESTORE DISPLAY", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            }
                            Switch(
                                checked = profile.restoreDisplayEnabled,
                                onCheckedChange = onRestoreDisplayToggle,
                                colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x3300E5FF))
                                .clickable { onForceRestoreAll() }
                                .padding(vertical = 5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "SYNC & RESTORE OVERLAYS",
                                color = NeonCyan,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // AIM CURSOR SECTION
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x220A1322),
                    border = BorderStroke(0.8.dp, if (profile.showCrosshair) NeonCyan.copy(alpha = 0.8f) else Color(0x22FFFFFF))
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isAimSectionOpen = !isAimSectionOpen },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.CropFree, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(15.dp))
                                Text("AIM CURSOR / MARKER", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Switch(
                                    checked = profile.showCrosshair,
                                    onCheckedChange = { onToggleCrosshair() },
                                    colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                                )
                                Icon(
                                    imageVector = if (isAimSectionOpen) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        if (isAimSectionOpen) {
                            Spacer(modifier = Modifier.height(8.dp))
                            // 15 Styles Preview Grid
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                AimCursorRenderer.STYLES.forEach { styleInfo ->
                                    val isSel = profile.crosshairStyle == styleInfo.key
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isSel) NeonCyan.copy(alpha = 0.25f) else Color(0x221B273C))
                                            .border(if (isSel) 1.2.dp else 0.6.dp, if (isSel) NeonCyan else Color(0x22FFFFFF), RoundedCornerShape(6.dp))
                                            .clickable { onUpdateCrosshairStyle(styleInfo.key) }
                                            .padding(horizontal = 4.dp, vertical = 3.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            AimCursorPreview(style = styleInfo.key, color = Color(profile.crosshairColor), sizeDp = 12.dp)
                                            Text(styleInfo.key, color = if (isSel) NeonCyan else TextSecondary, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Colors
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AimCursorRenderer.PALETTE_COLORS.forEach { (cVal, _) ->
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(Color(cVal))
                                            .border(if (profile.crosshairColor == cVal) 2.dp else 0.8.dp, Color.White, CircleShape)
                                            .clickable { onUpdateCrosshairColor(cVal) }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Size, Transparency, Rotation
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Size: ${profile.crosshairSizeDp}dp", color = TextSecondary, fontSize = 8.sp)
                                Slider(value = profile.crosshairSizeDp.toFloat(), onValueChange = { onUpdateCrosshairSize(it.toInt()) }, valueRange = 12f..60f, modifier = Modifier.width(170.dp).height(20.dp))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Alpha: ${(profile.crosshairTransparency * 100).toInt()}%", color = TextSecondary, fontSize = 8.sp)
                                Slider(value = profile.crosshairTransparency, onValueChange = onUpdateCrosshairTransparency, valueRange = 0.1f..1.0f, modifier = Modifier.width(170.dp).height(20.dp))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Rot: ${profile.crosshairRotation.toInt()}°", color = TextSecondary, fontSize = 8.sp)
                                Slider(value = profile.crosshairRotation, onValueChange = onUpdateCrosshairRotation, valueRange = 0f..360f, modifier = Modifier.width(170.dp).height(20.dp))
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            DirectionalPositionController(
                                title = "Aim Position",
                                x = profile.crosshairOffsetX,
                                y = profile.crosshairOffsetY,
                                defaultX = 0,
                                defaultY = 0,
                                minX = -600,
                                maxX = 600,
                                minY = -600,
                                maxY = 600,
                                onPositionChange = onUpdateCrosshairOffset
                            )
                        }
                    }
                }

                // MACRO [E] BUTTON SECTION (PRESS-AND-HOLD TRIGGER)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x220A1322),
                    border = BorderStroke(0.8.dp, if (profile.macroEEnabled) NeonCyan.copy(alpha = 0.8f) else Color(0x22FFFFFF))
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isMacroESectionOpen = !isMacroESectionOpen },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Keyboard, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(15.dp))
                                Column {
                                    Text("MACRO [E] TRIGGER", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    Text("Press-and-Hold • Interval: ${profile.macroETapSpeedMs}ms", color = TextSecondary, fontSize = 7.5.sp)
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Switch(
                                    checked = profile.macroEEnabled,
                                    onCheckedChange = onToggleMacroE,
                                    colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                                )
                                Icon(
                                    imageVector = if (isMacroESectionOpen) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        if (isMacroESectionOpen) {
                            Spacer(modifier = Modifier.height(8.dp))

                            // Interval setting with minimum 5 ms
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("TAP INTERVAL: ${profile.macroETapSpeedMs} ms", color = NeonCyan, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text("Delay between taps while E is held (min 5ms)", color = TextMuted, fontSize = 7.sp)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    PresetSizeButton("5ms", 5, profile.macroETapSpeedMs == 5) { onUpdateMacroEInterval(5) }
                                    PresetSizeButton("20ms", 20, profile.macroETapSpeedMs == 20) { onUpdateMacroEInterval(20) }
                                    PresetSizeButton("50ms", 50, profile.macroETapSpeedMs == 50) { onUpdateMacroEInterval(50) }
                                    PresetSizeButton("100ms", 100, profile.macroETapSpeedMs == 100) { onUpdateMacroEInterval(100) }
                                }
                            }
                            Slider(
                                value = profile.macroETapSpeedMs.toFloat(),
                                onValueChange = { onUpdateMacroEInterval(it.toInt()) },
                                valueRange = 5f..300f,
                                colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan),
                                modifier = Modifier.fillMaxWidth().height(20.dp)
                            )

                            // Size & Alpha
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Button Size: ${profile.macroESizeDp}dp", color = TextSecondary, fontSize = 8.sp)
                                Slider(value = profile.macroESizeDp.toFloat(), onValueChange = { onUpdateMacroESize(it.toInt()) }, valueRange = 32f..64f, modifier = Modifier.width(170.dp).height(20.dp))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Transparency: ${(profile.macroETransparency * 100).toInt()}%", color = TextSecondary, fontSize = 8.sp)
                                Slider(value = profile.macroETransparency, onValueChange = onUpdateMacroETransparency, valueRange = 0.2f..1.0f, modifier = Modifier.width(170.dp).height(20.dp))
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // E Button Position (Fixed coordinate control)
                            DirectionalPositionController(
                                title = "[E] Button Position (Fixed)",
                                x = profile.macroEPosX,
                                y = profile.macroEPosY,
                                defaultX = 120,
                                defaultY = 400,
                                minX = 0,
                                maxX = 3000,
                                minY = 0,
                                maxY = 3000,
                                onPositionChange = onUpdateMacroEButtonPos
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // E Target Position (Emote button coordinate)
                            DirectionalPositionController(
                                title = "[E] Target Position (Emote)",
                                x = profile.macroETargetX,
                                y = profile.macroETargetY,
                                defaultX = 540,
                                defaultY = 960,
                                minX = 0,
                                maxX = 3840,
                                minY = 0,
                                maxY = 3840,
                                onPositionChange = onUpdateMacroETargetPos
                            )
                        }
                    }
                }

                // MACRO [G] BUTTON SECTION (PRESS-AND-HOLD TRIGGER)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x220A1322),
                    border = BorderStroke(0.8.dp, if (profile.macroGEnabled) GamingAmber.copy(alpha = 0.8f) else Color(0x22FFFFFF))
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isMacroGSectionOpen = !isMacroGSectionOpen },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Keyboard, contentDescription = null, tint = GamingAmber, modifier = Modifier.size(15.dp))
                                Column {
                                    Text("MACRO [G] TRIGGER", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    Text("Press-and-Hold • Interval: ${profile.macroGTapSpeedMs}ms", color = TextSecondary, fontSize = 7.5.sp)
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Switch(
                                    checked = profile.macroGEnabled,
                                    onCheckedChange = onToggleMacroG,
                                    colors = SwitchDefaults.colors(checkedThumbColor = GamingAmber)
                                )
                                Icon(
                                    imageVector = if (isMacroGSectionOpen) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        if (isMacroGSectionOpen) {
                            Spacer(modifier = Modifier.height(8.dp))

                            // Interval setting with minimum 5 ms
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("TAP INTERVAL: ${profile.macroGTapSpeedMs} ms", color = GamingAmber, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text("Delay between taps while G is held (min 5ms)", color = TextMuted, fontSize = 7.sp)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    PresetSizeButton("5ms", 5, profile.macroGTapSpeedMs == 5, accentColor = GamingAmber) { onUpdateMacroGInterval(5) }
                                    PresetSizeButton("20ms", 20, profile.macroGTapSpeedMs == 20, accentColor = GamingAmber) { onUpdateMacroGInterval(20) }
                                    PresetSizeButton("50ms", 50, profile.macroGTapSpeedMs == 50, accentColor = GamingAmber) { onUpdateMacroGInterval(50) }
                                    PresetSizeButton("100ms", 100, profile.macroGTapSpeedMs == 100, accentColor = GamingAmber) { onUpdateMacroGInterval(100) }
                                }
                            }
                            Slider(
                                value = profile.macroGTapSpeedMs.toFloat(),
                                onValueChange = { onUpdateMacroGInterval(it.toInt()) },
                                valueRange = 5f..300f,
                                colors = SliderDefaults.colors(thumbColor = GamingAmber, activeTrackColor = GamingAmber),
                                modifier = Modifier.fillMaxWidth().height(20.dp)
                            )

                            // Size & Alpha (G is slightly larger than E)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Button Size: ${profile.macroGSizeDp}dp", color = TextSecondary, fontSize = 8.sp)
                                Slider(value = profile.macroGSizeDp.toFloat(), onValueChange = { onUpdateMacroGSize(it.toInt()) }, valueRange = 40f..76f, modifier = Modifier.width(170.dp).height(20.dp))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Transparency: ${(profile.macroGTransparency * 100).toInt()}%", color = TextSecondary, fontSize = 8.sp)
                                Slider(value = profile.macroGTransparency, onValueChange = onUpdateMacroGTransparency, valueRange = 0.2f..1.0f, modifier = Modifier.width(170.dp).height(20.dp))
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // G Button Position (Fixed coordinate control)
                            DirectionalPositionController(
                                title = "[G] Button Position (Fixed)",
                                x = profile.macroGPosX,
                                y = profile.macroGPosY,
                                defaultX = 120,
                                defaultY = 520,
                                minX = 0,
                                maxX = 3000,
                                minY = 0,
                                maxY = 3000,
                                onPositionChange = onUpdateMacroGButtonPos
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // G Target Position (J button coordinate)
                            DirectionalPositionController(
                                title = "[G] Target Position (J Button)",
                                x = profile.macroGTargetX,
                                y = profile.macroGTargetY,
                                defaultX = 540,
                                defaultY = 1100,
                                minX = 0,
                                maxX = 3840,
                                minY = 0,
                                maxY = 3840,
                                onPositionChange = onUpdateMacroGTargetPos
                            )
                        }
                    }
                }

                // OVERLAY MENU SIZE & TRANSPARENCY SLIDERS (DYNAMIC LIVE SCALING)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x22050B14),
                    border = BorderStroke(0.6.dp, Color(0x22FFFFFF))
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Menu Size: ${(profile.expandedMenuSize * 100).toInt()}%", color = TextSecondary, fontSize = 8.5.sp)
                            Slider(
                                value = profile.expandedMenuSize,
                                onValueChange = onUpdateMenuSize,
                                valueRange = 0.65f..1.4f,
                                colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan),
                                modifier = Modifier.width(170.dp).height(20.dp)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Menu Opacity: ${(profile.overlayAlpha * 100).toInt()}%", color = TextSecondary, fontSize = 8.5.sp)
                            Slider(
                                value = profile.overlayAlpha,
                                onValueChange = onUpdateTransparency,
                                valueRange = 0.25f..1.0f,
                                colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan),
                                modifier = Modifier.width(170.dp).height(20.dp)
                            )
                        }
                    }
                }

                // Quick Navigation Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onOpenApp,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x3300E5FF)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Launch, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("DASHBOARD", color = NeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onCollapse,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FFFFFF)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("MINIMIZE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PresetSizeButton(
    label: String,
    sizeDp: Int,
    isSelected: Boolean,
    accentColor: Color = NeonCyan,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) accentColor else Color(0x221B273C))
            .border(0.6.dp, if (isSelected) accentColor else Color(0x33FFFFFF), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.Black else TextSecondary,
            fontSize = 7.5.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun TimingEditorBox(
    label: String,
    speedMs: Int,
    explanation: String,
    accentColor: Color = NeonCyan,
    onSpeedChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .border(0.6.dp, Color(0x22FFFFFF), RoundedCornerShape(8.dp)),
        color = Color(0x18FFFFFF),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = accentColor, fontSize = 7.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0x33101C30))
                        .clickable { onSpeedChange((speedMs - 10).coerceAtLeast(5)) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("-", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "$speedMs ms",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )

                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0x33101C30))
                        .clickable { onSpeedChange(speedMs + 10) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("+", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(explanation, color = TextMuted, fontSize = 6.5.sp, lineHeight = 8.5.sp)
        }
    }
}
