package com.srtxcheats.ui.overlay

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.srtxcheats.ui.theme.GamingAmber
import com.srtxcheats.ui.theme.NeonCyan

/**
 * MacroOverlayButton:
 * Fixed, circular trigger button for Macro [E] and [G].
 *
 * SPECIFICATION & FIXES:
 * - Round / Circular shape.
 * - Completely NON-DRAGGABLE directly (fixed at coordinates set in menu).
 * - Instantaneous Press-and-Hold input detection (ACTION_DOWN starts macro, ACTION_UP/CANCEL stops).
 * - rememberUpdatedState to ensure fresh callback execution on every gesture.
 * - DisposableEffect to guarantee immediate macro stoppage if button view is dismissed while held.
 * - Does not swallow unrelated touches outside the circular bounds.
 * - G is slightly larger than E.
 * - No target circles rendered over the game.
 */
@Composable
fun MacroOverlayButton(
    label: String, // "E" or "G"
    sizeDp: Int,
    transparency: Float,
    isRunning: Boolean,
    accentColor: Color = if (label == "E") NeonCyan else GamingAmber,
    onPressDown: () -> Unit,
    onPressUp: () -> Unit,
    modifier: Modifier = Modifier
) {
    val alpha = transparency.coerceIn(0.15f, 1.0f)
    val currentOnPressDown by rememberUpdatedState(onPressDown)
    val currentOnPressUp by rememberUpdatedState(onPressUp)

    // Ensure macro stops immediately if the overlay button leaves composition while being held
    DisposableEffect(label) {
        onDispose {
            currentOnPressUp()
        }
    }

    // Pulsing animation when running
    val infiniteTransition = rememberInfiniteTransition(label = "macro_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isRunning) 1.15f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Surface(
        modifier = modifier
            .size(sizeDp.dp)
            .scale(if (isRunning) pulseScale else 1f)
            .clip(CircleShape)
            .pointerInput(label) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    currentOnPressDown()
                    waitForUpOrCancellation()
                    currentOnPressUp()
                }
            }
            .testTag("macro_trigger_$label"),
        shape = CircleShape,
        color = Color(0xF0060A14).copy(alpha = alpha),
        border = BorderStroke(
            width = if (isRunning) 2.5.dp else 1.5.dp,
            brush = Brush.linearGradient(
                listOf(
                    accentColor,
                    if (isRunning) Color.White else accentColor.copy(alpha = 0.6f),
                    accentColor
                )
            )
        ),
        shadowElevation = 8.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (isRunning) accentColor.copy(alpha = 0.25f) else Color.Transparent
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                color = if (isRunning) Color.White else accentColor,
                fontSize = (sizeDp * 0.48f).sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = (-0.5).sp
            )
        }
    }
}
