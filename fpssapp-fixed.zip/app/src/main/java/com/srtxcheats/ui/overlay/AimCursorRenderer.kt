package com.srtxcheats.ui.overlay

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * AimCursorRenderer:
 * High-precision canvas renderer for 15 tactical crosshair / aim cursor styles.
 * Supports arbitrary rotation (0° - 360°), alpha transparency (0% - 100%),
 * and custom sizing.
 */
object AimCursorRenderer {

    data class CursorStyleInfo(
        val key: String,
        val displayName: String,
        val description: String
    )

    val STYLES = listOf(
        CursorStyleInfo("CROSS", "Classic Cross", "Standard 4-axis gaming crosshair with center pip"),
        CursorStyleInfo("DOT", "Precision Dot", "Solid illuminated tactical center dot"),
        CursorStyleInfo("CIRCLE", "Target Circle", "Precision circle with center dot"),
        CursorStyleInfo("RETICLE", "Tactical Reticle", "Military cross-bracket reticle with radius ring"),
        CursorStyleInfo("HOLLOW_CIRCLE", "Hollow Ring", "Minimalist open target circle without center dot"),
        CursorStyleInfo("CHEVRON", "Apex Chevron", "Tactical FPS inverted-V chevron sight"),
        CursorStyleInfo("DIAMOND", "Diamond Pip", "Diamond target frame with center aim point"),
        CursorStyleInfo("TRIANGLE", "Delta Triangle", "Precision triangle reticle"),
        CursorStyleInfo("T_STYLE", "T-Post", "3-axis T-bar sight with open top viewport"),
        CursorStyleInfo("BOX_CROSS", "Boxed Cross", "Tactical corner bracket box enclosing a center cross"),
        CursorStyleInfo("SNIPER_DOT", "Sniper Scope", "Dual concentric precision rings with fine crosshairs"),
        CursorStyleInfo("BIOHAZARD", "Tri-Arc", "3-blade orbital arc gamer sight"),
        CursorStyleInfo("STARBURST", "Starburst", "8-point radial tactical star reticle"),
        CursorStyleInfo("RING_DOT", "Ring & Dot", "Heavy outer target ring with luminous center pip"),
        CursorStyleInfo("CROSS_PRO", "Crosshair Pro", "Pro crosshair with graduated range tick notches")
    )

    // 22 Vivid Gamer Palette Colors
    val PALETTE_COLORS = listOf(
        0xFF00E5FF to "Neon Cyan",
        0xFFFF1744 to "Crimson Red",
        0xFF00E676 to "Electric Green",
        0xFFFFD600 to "Amber Yellow",
        0xFFFFFFFF to "Pure White",
        0xFFD500F9 to "Electric Purple",
        0xFFFF4081 to "Hot Pink",
        0xFF76FF03 to "Lime Glow",
        0xFF00B0FF to "Deep Sky Blue",
        0xFFFF6D00 to "Flame Orange",
        0xFFFFC107 to "Radiant Gold",
        0xFFFF5252 to "Coral Flame",
        0xFF1DE9B6 to "Mint Breeze",
        0xFF7C4DFF to "Deep Violet",
        0xFF80D8FF to "Ice Blue",
        0xFF00C853 to "Emerald Glow",
        0xFFFF007F to "Vivid Magenta",
        0xFFFFAB00 to "Sunburst",
        0xFF2979FF to "Electric Blue",
        0xFFF48FB1 to "Rose Quartz",
        0xFF3D5AFE to "Ultramarine",
        0xFFCFD8DC to "Stealth Silver"
    )

    fun drawCursor(
        drawScope: DrawScope,
        style: String,
        color: Color,
        rotationDeg: Float = 0f,
        alpha: Float = 1.0f
    ) {
        val renderColor = color.copy(alpha = (color.alpha * alpha).coerceIn(0f, 1f))
        val center = Offset(drawScope.size.width / 2f, drawScope.size.height / 2f)
        val radius = drawScope.size.width / 2f
        val strokeWidth = 2.2f

        drawScope.rotate(degrees = rotationDeg, pivot = center) {
            when (style) {
                "DOT" -> {
                    drawCircle(color = renderColor.copy(alpha = renderColor.alpha * 0.35f), radius = radius * 0.45f, center = center)
                    drawCircle(color = renderColor, radius = radius * 0.22f, center = center)
                }

                "CIRCLE" -> {
                    drawCircle(color = renderColor, radius = radius * 0.72f, center = center, style = Stroke(width = strokeWidth))
                    drawCircle(color = renderColor, radius = 2.5f, center = center)
                }

                "HOLLOW_CIRCLE" -> {
                    drawCircle(color = renderColor, radius = radius * 0.75f, center = center, style = Stroke(width = strokeWidth * 1.1f))
                }

                "RETICLE" -> {
                    drawCircle(color = renderColor.copy(alpha = renderColor.alpha * 0.8f), radius = radius * 0.75f, center = center, style = Stroke(width = 1.8f))
                    drawCircle(color = renderColor, radius = 2f, center = center)
                    drawLine(renderColor, Offset(center.x, 0f), Offset(center.x, radius * 0.35f), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x, drawScope.size.height), Offset(center.x, drawScope.size.height - radius * 0.35f), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(0f, center.y), Offset(radius * 0.35f, center.y), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(drawScope.size.width, center.y), Offset(drawScope.size.width - radius * 0.35f, center.y), strokeWidth = strokeWidth)
                }

                "CHEVRON" -> {
                    val path = Path().apply {
                        moveTo(center.x - radius * 0.65f, center.y + radius * 0.35f)
                        lineTo(center.x, center.y - radius * 0.45f)
                        lineTo(center.x + radius * 0.65f, center.y + radius * 0.35f)
                    }
                    drawPath(path = path, color = renderColor, style = Stroke(width = strokeWidth * 1.2f, cap = StrokeCap.Round))
                    drawCircle(color = renderColor, radius = 2f, center = Offset(center.x, center.y - radius * 0.45f))
                }

                "DIAMOND" -> {
                    val path = Path().apply {
                        moveTo(center.x, center.y - radius * 0.7f)
                        lineTo(center.x + radius * 0.7f, center.y)
                        lineTo(center.x, center.y + radius * 0.7f)
                        lineTo(center.x - radius * 0.7f, center.y)
                        close()
                    }
                    drawPath(path = path, color = renderColor, style = Stroke(width = strokeWidth))
                    drawCircle(color = renderColor, radius = 2f, center = center)
                }

                "TRIANGLE" -> {
                    val path = Path().apply {
                        moveTo(center.x, center.y - radius * 0.75f)
                        lineTo(center.x + radius * 0.65f, center.y + radius * 0.55f)
                        lineTo(center.x - radius * 0.65f, center.y + radius * 0.55f)
                        close()
                    }
                    drawPath(path = path, color = renderColor, style = Stroke(width = strokeWidth))
                    drawCircle(color = renderColor, radius = 2f, center = center)
                }

                "T_STYLE" -> {
                    val gap = 4f
                    // Left, Right, Down (no up arm)
                    drawLine(renderColor, Offset(center.x - gap, center.y), Offset(0f, center.y), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x + gap, center.y), Offset(drawScope.size.width, center.y), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x, center.y + gap), Offset(center.x, drawScope.size.height), strokeWidth = strokeWidth)
                    drawCircle(color = renderColor, radius = 2f, center = center)
                }

                "BOX_CROSS" -> {
                    val boxSize = radius * 0.65f
                    val bracketLen = radius * 0.25f
                    // 4 corner brackets
                    // Top-Left
                    drawLine(renderColor, Offset(center.x - boxSize, center.y - boxSize), Offset(center.x - boxSize + bracketLen, center.y - boxSize), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x - boxSize, center.y - boxSize), Offset(center.x - boxSize, center.y - boxSize + bracketLen), strokeWidth = strokeWidth)
                    // Top-Right
                    drawLine(renderColor, Offset(center.x + boxSize, center.y - boxSize), Offset(center.x + boxSize - bracketLen, center.y - boxSize), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x + boxSize, center.y - boxSize), Offset(center.x + boxSize, center.y - boxSize + bracketLen), strokeWidth = strokeWidth)
                    // Bottom-Left
                    drawLine(renderColor, Offset(center.x - boxSize, center.y + boxSize), Offset(center.x - boxSize + bracketLen, center.y + boxSize), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x - boxSize, center.y + boxSize), Offset(center.x - boxSize, center.y + boxSize - bracketLen), strokeWidth = strokeWidth)
                    // Bottom-Right
                    drawLine(renderColor, Offset(center.x + boxSize, center.y + boxSize), Offset(center.x + boxSize - bracketLen, center.y + boxSize), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x + boxSize, center.y + boxSize), Offset(center.x + boxSize, center.y + boxSize - bracketLen), strokeWidth = strokeWidth)
                    // Center small cross
                    drawLine(renderColor, Offset(center.x - 4f, center.y), Offset(center.x + 4f, center.y), strokeWidth = 1.8f)
                    drawLine(renderColor, Offset(center.x, center.y - 4f), Offset(center.x, center.y + 4f), strokeWidth = 1.8f)
                }

                "SNIPER_DOT" -> {
                    // Outer ring
                    drawCircle(color = renderColor, radius = radius * 0.85f, center = center, style = Stroke(width = 1.6f))
                    // Inner ring
                    drawCircle(color = renderColor.copy(alpha = renderColor.alpha * 0.7f), radius = radius * 0.4f, center = center, style = Stroke(width = 1.2f))
                    // 4 Hairlines
                    drawLine(renderColor, Offset(center.x, 0f), Offset(center.x, center.y - radius * 0.4f), strokeWidth = 1.4f)
                    drawLine(renderColor, Offset(center.x, center.y + radius * 0.4f), Offset(center.x, drawScope.size.height), strokeWidth = 1.4f)
                    drawLine(renderColor, Offset(0f, center.y), Offset(center.x - radius * 0.4f, center.y), strokeWidth = 1.4f)
                    drawLine(renderColor, Offset(center.x + radius * 0.4f, center.y), Offset(drawScope.size.width, center.y), strokeWidth = 1.4f)
                    drawCircle(color = renderColor, radius = 2f, center = center)
                }

                "BIOHAZARD" -> {
                    // 3 Arcs at 120 degrees
                    for (i in 0..2) {
                        val angle = i * 120.0f - 90f
                        val arcRadius = radius * 0.45f
                        val rad = angle * (PI / 180.0)
                        val arcCenter = Offset(
                            (center.x + cos(rad) * radius * 0.35f).toFloat(),
                            (center.y + sin(rad) * radius * 0.35f).toFloat()
                        )
                        drawCircle(
                            color = renderColor,
                            radius = arcRadius,
                            center = arcCenter,
                            style = Stroke(width = 1.8f)
                        )
                    }
                    drawCircle(color = renderColor, radius = 2.5f, center = center)
                }

                "STARBURST" -> {
                    // 8 radial lines
                    val innerR = radius * 0.28f
                    val outerR = radius * 0.85f
                    for (i in 0..7) {
                        val angle = i * 45.0 * (PI / 180.0)
                        val p1 = Offset((center.x + cos(angle) * innerR).toFloat(), (center.y + sin(angle) * innerR).toFloat())
                        val p2 = Offset((center.x + cos(angle) * outerR).toFloat(), (center.y + sin(angle) * outerR).toFloat())
                        drawLine(renderColor, p1, p2, strokeWidth = 1.8f, cap = StrokeCap.Round)
                    }
                    drawCircle(color = renderColor, radius = 1.8f, center = center)
                }

                "RING_DOT" -> {
                    drawCircle(color = renderColor, radius = radius * 0.68f, center = center, style = Stroke(width = 3.2f))
                    drawCircle(color = renderColor, radius = 3.5f, center = center)
                }

                "CROSS_PRO" -> {
                    val gap = 5f
                    // 4 main cross arms
                    drawLine(renderColor, Offset(center.x, center.y - gap), Offset(center.x, 0f), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x, center.y + gap), Offset(center.x, drawScope.size.height), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x - gap, center.y), Offset(0f, center.y), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x + gap, center.y), Offset(drawScope.size.width, center.y), strokeWidth = strokeWidth)
                    // Tick marks on arms
                    val tickOffset = radius * 0.55f
                    val tickLen = 4f
                    drawLine(renderColor, Offset(center.x - tickLen, center.y - tickOffset), Offset(center.x + tickLen, center.y - tickOffset), strokeWidth = 1.5f)
                    drawLine(renderColor, Offset(center.x - tickLen, center.y + tickOffset), Offset(center.x + tickLen, center.y + tickOffset), strokeWidth = 1.5f)
                    drawLine(renderColor, Offset(center.x - tickOffset, center.y - tickLen), Offset(center.x - tickOffset, center.y + tickLen), strokeWidth = 1.5f)
                    drawLine(renderColor, Offset(center.x + tickOffset, center.y - tickLen), Offset(center.x + tickOffset, center.y + tickLen), strokeWidth = 1.5f)
                    drawCircle(color = renderColor, radius = 2f, center = center)
                }

                else -> { // "CROSS" default
                    val gap = 5f
                    drawLine(renderColor, Offset(center.x, center.y - gap), Offset(center.x, 0f), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x, center.y + gap), Offset(center.x, drawScope.size.height), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x - gap, center.y), Offset(0f, center.y), strokeWidth = strokeWidth)
                    drawLine(renderColor, Offset(center.x + gap, center.y), Offset(drawScope.size.width, center.y), strokeWidth = strokeWidth)
                    drawCircle(color = renderColor, radius = 1.8f, center = center)
                }
            }
        }
    }
}

/**
 * Preview Composable for Aim Cursor in lists or standalone preview.
 */
@Composable
fun AimCursorPreview(
    style: String,
    color: Color,
    sizeDp: Dp = 28.dp,
    rotationDeg: Float = 0f,
    alpha: Float = 1.0f,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(sizeDp)) {
        AimCursorRenderer.drawCursor(
            drawScope = this,
            style = style,
            color = color,
            rotationDeg = rotationDeg,
            alpha = alpha
        )
    }
}
