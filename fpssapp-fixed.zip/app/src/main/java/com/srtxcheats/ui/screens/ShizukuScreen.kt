package com.srtxcheats.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.srtxcheats.core.ShizukuManager
import com.srtxcheats.ui.components.GlassCard
import com.srtxcheats.ui.theme.AmoledBackground
import com.srtxcheats.ui.theme.GamingAmber
import com.srtxcheats.ui.theme.GamingCrimson
import com.srtxcheats.ui.theme.GamingGreen
import com.srtxcheats.ui.theme.NeonCyan
import com.srtxcheats.ui.theme.TextMuted
import com.srtxcheats.ui.theme.TextPrimary
import com.srtxcheats.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun ShizukuScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var shizukuState by remember { mutableStateOf(ShizukuManager.checkState(context)) }
    var isAuthorized by remember { mutableStateOf(ShizukuManager.isAuthorized()) }
    var deviceProps by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var capabilities by remember { mutableStateOf<ShizukuManager.CapabilityCheck?>(null) }
    var testResultOutput by remember { mutableStateOf<String?>(null) }
    var isExecutingCommand by remember { mutableStateOf(false) }
    var customShellCmd by remember { mutableStateOf("") }
    val consoleLogs = remember {
        mutableStateListOf(
            "⚡ Shizuku privileged gaming terminal initialized",
            "✓ Ready for real-time ADB system optimizations"
        )
    }
    var isPerformanceGovernorEnabled by remember { mutableStateOf(false) }
    var is120HzLocked by remember { mutableStateOf(false) }
    var isGameDozeExempted by remember { mutableStateOf(false) }

    fun refreshStatus() {
        shizukuState = ShizukuManager.checkState(context)
        isAuthorized = ShizukuManager.isAuthorized()
        coroutineScope.launch {
            capabilities = ShizukuManager.detectCapabilities()
            if (isAuthorized) {
                deviceProps = ShizukuManager.readDeviceProperties()
            }
        }
    }

    LaunchedEffect(Unit) {
        refreshStatus()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("shizuku_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SHIZUKU & ADB CONTROL",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Privileged system telemetry & safe hardware tuning",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            OutlinedButton(
                onClick = { refreshStatus() },
                modifier = Modifier.height(36.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.linearGradient(listOf(NeonCyan, Color(0x3300E5FF)))
                )
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = NeonCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("REFRESH", color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Shizuku Service Status Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            glowAccent = shizukuState == ShizukuManager.ShizukuState.CONNECTED && isAuthorized
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                when (shizukuState) {
                                    ShizukuManager.ShizukuState.CONNECTED -> GamingGreen
                                    ShizukuManager.ShizukuState.SERVICE_NOT_RUNNING -> GamingAmber
                                    ShizukuManager.ShizukuState.NOT_INSTALLED -> GamingCrimson
                                }
                            )
                    )
                    Column {
                        Text(
                            text = "SHIZUKU SERVICE",
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = when (shizukuState) {
                                ShizukuManager.ShizukuState.CONNECTED -> "RUNNING & BINDER CONNECTED"
                                ShizukuManager.ShizukuState.SERVICE_NOT_RUNNING -> "INSTALLED (SERVICE NOT RUNNING)"
                                ShizukuManager.ShizukuState.NOT_INSTALLED -> "NOT INSTALLED"
                            },
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Action buttons based on state
                when (shizukuState) {
                    ShizukuManager.ShizukuState.NOT_INSTALLED -> {
                        Button(
                            onClick = { ShizukuManager.openShizukuWebsite(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("INSTALL", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    ShizukuManager.ShizukuState.SERVICE_NOT_RUNNING -> {
                        Button(
                            onClick = { ShizukuManager.openShizukuApp(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = GamingAmber),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("OPEN SHIZUKU", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    ShizukuManager.ShizukuState.CONNECTED -> {
                        if (!isAuthorized) {
                            Button(
                                onClick = { ShizukuManager.requestPermission() },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("AUTHORIZE", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0x3300E676))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("GRANTED", color = GamingGreen, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // PRIVILEGED GAMING OPTIMIZER & INTERACTIVE TERMINAL
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            glowAccent = isAuthorized
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isAuthorized) GamingGreen else TextMuted)
                    )
                    Column {
                        Text(
                            text = "SHIZUKU GAMING ENGINE",
                            color = if (isAuthorized) NeonCyan else TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = if (isAuthorized) {
                                "Authorized • Privileged Hardware & Governor Access"
                            } else {
                                "Unauthorized • Grant Shizuku permission to enable"
                            },
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // PRIVILEGED GAMING ACTIONS
            Text(
                text = "ONE-TAP HARDWARE & GOVERNOR OPTIMIZATION",
                color = TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Performance Mode Governor
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x221E293B))
                        .border(0.6.dp, Color(0x3300E5FF), RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("FIXED PERFORMANCE GOVERNOR", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Forces CPU/GPU clock stability and mitigates thermal throttle", color = TextSecondary, fontSize = 9.sp)
                    }
                    Switch(
                        checked = isPerformanceGovernorEnabled,
                        onCheckedChange = { enable ->
                            isPerformanceGovernorEnabled = enable
                            coroutineScope.launch {
                                val cmd = if (enable) "cmd power set-fixed-performance-mode-enabled true" else "cmd power set-fixed-performance-mode-enabled false"
                                val res = ShizukuManager.executeCommand(cmd)
                                consoleLogs.add("⚡ [GOVERNOR] $cmd -> exit=${res.exitCode}")
                            }
                        },
                        enabled = isAuthorized,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = NeonCyan)
                    )
                }

                // 120Hz Display Lock
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x221E293B))
                        .border(0.6.dp, Color(0x3300E5FF), RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("MAX REFRESH RATE ENFORCEMENT", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Locks peak & min refresh rate to 120Hz for fluid frame delivery", color = TextSecondary, fontSize = 9.sp)
                    }
                    Switch(
                        checked = is120HzLocked,
                        onCheckedChange = { lock ->
                            is120HzLocked = lock
                            coroutineScope.launch {
                                val peakCmd = if (lock) "settings put system peak_refresh_rate 120" else "settings put system peak_refresh_rate 60"
                                val minCmd = if (lock) "settings put system min_refresh_rate 120" else "settings delete system min_refresh_rate"
                                ShizukuManager.executeCommand(peakCmd)
                                ShizukuManager.executeCommand(minCmd)
                                consoleLogs.add("🖥️ [REFRESH_RATE] Enforced 120Hz peak/min lock: $lock")
                            }
                        },
                        enabled = isAuthorized,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = NeonCyan)
                    )
                }

                // Quick Process Killer & Doze Exemption
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val res = ShizukuManager.executeCommand("cmd activity kill-all")
                                consoleLogs.add("🧹 [KILL_BACKGROUND] cmd activity kill-all -> exit=${res.exitCode}")
                            }
                        },
                        enabled = isAuthorized,
                        modifier = Modifier.weight(1f).height(38.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x3300E676)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, tint = GamingGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("DEEP RAM CLEAN", color = GamingGreen, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val pkg = "com.dts.freefiremax"
                                val res = ShizukuManager.executeCommand("dumpsys deviceidle whitelist +$pkg")
                                isGameDozeExempted = true
                                consoleLogs.add("🛡️ [DOZE_EXEMPT] Added $pkg to Doze whitelist")
                            }
                        },
                        enabled = isAuthorized,
                        modifier = Modifier.weight(1f).height(38.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x3300E5FF)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("EXEMPT DOZE", color = NeonCyan, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // CUSTOM SHELL COMMAND EXECUTION
            Text(
                text = "EXECUTE PRIVILEGED SHELL COMMAND (SHIZUKU/ADB)",
                color = TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = customShellCmd,
                    onValueChange = { customShellCmd = it },
                    placeholder = { Text("e.g. dumpsys battery | grep -i level", color = TextMuted, fontSize = 10.sp) },
                    modifier = Modifier.weight(1f).height(50.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = Color(0x44334155),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                )

                Button(
                    onClick = {
                        if (customShellCmd.isNotBlank()) {
                            val cmd = customShellCmd.trim()
                            customShellCmd = ""
                            coroutineScope.launch {
                                consoleLogs.add("> $cmd")
                                val res = ShizukuManager.executeCommand(cmd)
                                if (res.output.isNotBlank()) {
                                    res.output.lines().take(5).forEach { consoleLogs.add("  $it") }
                                }
                                if (res.error.isNotBlank()) {
                                    consoleLogs.add("  err: ${res.error}")
                                }
                                consoleLogs.add("  [exit ${res.exitCode}]")
                            }
                        }
                    },
                    modifier = Modifier.height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RUN", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // REAL-TIME SHELL EXECUTION LOG CONSOLE
            if (consoleLogs.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TERMINAL EXECUTION LOG",
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "CLEAR",
                        color = GamingCrimson,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { consoleLogs.clear() }
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF06090F))
                        .border(0.6.dp, Color(0x33334155), RoundedCornerShape(6.dp))
                        .padding(8.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        consoleLogs.forEach { logLine ->
                            Text(
                                text = logLine,
                                color = if (logLine.startsWith(">")) NeonCyan else if (logLine.contains("err:")) GamingCrimson else TextSecondary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SHIZUKU CAPABILITY CHECK BOX
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "SHIZUKU CAPABILITY CHECK",
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (isAuthorized) "REAL TIME" else "AWAITING BINDER",
                    color = if (isAuthorized) GamingGreen else TextMuted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            val cap = capabilities
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x400C1322))
                    .border(0.6.dp, Color(0x3300E5FF), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CapabilityRow(
                    title = "SHIZUKU",
                    status = when (shizukuState) {
                        ShizukuManager.ShizukuState.CONNECTED -> "CONNECTED"
                        ShizukuManager.ShizukuState.SERVICE_NOT_RUNNING -> "NOT RUNNING"
                        ShizukuManager.ShizukuState.NOT_INSTALLED -> "NOT INSTALLED"
                    },
                    isSuccess = shizukuState == ShizukuManager.ShizukuState.CONNECTED
                )

                CapabilityRow(
                    title = "PERFORMANCE API",
                    status = if (cap?.performanceApiAvailable == true) "AVAILABLE" else "NOT AVAILABLE",
                    isSuccess = cap?.performanceApiAvailable == true
                )

                CapabilityRow(
                    title = "GAME MODE",
                    status = if (cap?.gameModeAvailable == true) "AVAILABLE" else "NOT AVAILABLE",
                    isSuccess = cap?.gameModeAvailable == true
                )

                CapabilityRow(
                    title = "SUPPORTED SYSTEM OPTIMIZATION",
                    status = if (cap?.systemOptAvailable == true) "AVAILABLE" else "NOT AVAILABLE",
                    isSuccess = cap?.systemOptAvailable == true
                )

                CapabilityRow(
                    title = "UNSUPPORTED FEATURES",
                    status = "${cap?.unsupportedCount ?: 2} RESTRICTED",
                    isSuccess = true,
                    overrideColor = Color(0xFFFF9100)
                )

                cap?.unsupportedDetails?.forEach { detail ->
                    Text(
                        text = "• $detail",
                        color = Color(0xFFB0BEC5),
                        fontSize = 9.sp,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Safe Privileged System Telemetry (if authorized)
        if (isAuthorized && deviceProps.isNotEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "PRIVILEGED SYSTEM PROPERTIES (SHIZUKU)",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                deviceProps.forEach { (prop, value) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(prop, color = TextSecondary, fontSize = 11.sp)
                        Text(value, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Safe Tuning & Diagnostics Action
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "SAFE DEVICE OPTIMIZATION EXECUTION",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tests safe system property reads and verification. Never crashes if restricted.",
                color = TextSecondary,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isExecutingCommand = true
                            val res = ShizukuManager.executeCommand("dumpsys battery | grep -i temperature")
                            testResultOutput = if (res.exitCode == 0 && res.output.isNotBlank()) {
                                "Output: ${res.output}"
                            } else {
                                "Result: Operation not supported on this device or restricted."
                            }
                            isExecutingCommand = false
                        }
                    },
                    enabled = isAuthorized && !isExecutingCommand,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x3300E5FF)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("DIAGNOSE BATTERY", color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        coroutineScope.launch {
                            isExecutingCommand = true
                            val res = ShizukuManager.executeCommand("settings get system pointer_speed")
                            testResultOutput = if (res.exitCode == 0 && res.output.isNotBlank()) {
                                "Pointer speed setting: ${res.output} (Normal range: 0-7)"
                            } else {
                                "Result: Operation not supported on this device"
                            }
                            isExecutingCommand = false
                        }
                    },
                    enabled = isAuthorized && !isExecutingCommand,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x3300E676)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("READ POINTER SPEED", color = GamingGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            testResultOutput?.let { out ->
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF06090F))
                        .border(0.5.dp, Color(0x33FFFFFF), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(out, color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Step-by-step Wireless Debugging Guide
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "WIRELESS DEBUGGING SETUP GUIDE",
                color = GamingAmber,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            val steps = listOf(
                "1. Enable Developer Options on your device (Settings > About Phone > Tap 'Build Number' 7 times)",
                "2. In Developer Options, enable 'Wireless Debugging' (ensure connected to Wi-Fi)",
                "3. Open Shizuku and tap 'Pairing' under Wireless Debugging",
                "4. Enter the 6-digit Wi-Fi pairing code displayed by Android",
                "5. Tap 'Start' in Shizuku",
                "6. Return to SRT X CHEATS and tap [AUTHORIZE]"
            )

            steps.forEach { step ->
                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .padding(top = 4.dp)
                            .clip(CircleShape)
                            .background(NeonCyan)
                    )
                    Text(step, color = TextSecondary, fontSize = 10.5.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x33FF9100)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.DeveloperMode, contentDescription = null, tint = GamingAmber, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("DEV OPTIONS", color = GamingAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { ShizukuManager.openShizukuApp(context) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x3300E5FF)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Launch, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("OPEN SHIZUKU", color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun CapabilityRow(
    title: String,
    status: String,
    isSuccess: Boolean,
    overrideColor: Color? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            color = Color(0xFFCFD8DC),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
        val color = overrideColor ?: if (isSuccess) GamingGreen else Color(0xFFFF5252)
        Text(
            text = "${if (isSuccess && overrideColor == null) "✓ " else ""}$status",
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace
        )
    }
}
