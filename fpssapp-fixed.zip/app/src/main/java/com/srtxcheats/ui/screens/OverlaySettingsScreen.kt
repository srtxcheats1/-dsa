package com.srtxcheats.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.srtxcheats.model.DeviceMetrics
import com.srtxcheats.model.GameProfile
import com.srtxcheats.ui.components.DirectionalPositionController
import com.srtxcheats.ui.components.GlassCard
import com.srtxcheats.ui.overlay.AimCursorPreview
import com.srtxcheats.ui.overlay.AimCursorRenderer
import com.srtxcheats.ui.overlay.FloatingOverlayContent
import com.srtxcheats.ui.overlay.PresetSizeButton
import com.srtxcheats.ui.overlay.TimingEditorBox
import com.srtxcheats.ui.theme.AmoledBackground
import com.srtxcheats.ui.theme.GamingAmber
import com.srtxcheats.ui.theme.GamingCrimson
import com.srtxcheats.ui.theme.GamingGreen
import com.srtxcheats.ui.theme.NeonCyan
import com.srtxcheats.ui.theme.TextMuted
import com.srtxcheats.ui.theme.TextPrimary
import com.srtxcheats.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OverlaySettingsScreen(
    profile: GameProfile,
    logoBitmap: Bitmap?,
    onUpdateScale: (Float) -> Unit,
    onUpdateMenuSize: (Float) -> Unit = {},
    onUpdateAlpha: (Float) -> Unit,
    onUpdateTransparency: (Float) -> Unit = {},
    onUpdateGlassBlur: (String) -> Unit = {},
    onToggleMetric: (String, Boolean) -> Unit,
    onToggleCrosshair: (Boolean) -> Unit,
    onUpdateCrosshairSettings: (String, Long, Int) -> Unit,
    onUpdateCrosshairOffset: (Int, Int) -> Unit = { _, _ -> },
    onToggleGraph: (Boolean) -> Unit,
    onRestoreDisplayToggle: (Boolean) -> Unit = {},
    onForceRestoreAll: () -> Unit = {},
    onUpdateCrosshairTransparency: (Float) -> Unit = {},
    onUpdateCrosshairRotation: (Float) -> Unit = {},
    onToggleMacroE: (Boolean) -> Unit = {},
    onUpdateMacroESize: (Int) -> Unit = {},
    onUpdateMacroETransparency: (Float) -> Unit = {},
    onUpdateMacroEButtonPos: (Int, Int) -> Unit = { _, _ -> },
    onUpdateMacroETargetPos: (Int, Int) -> Unit = { _, _ -> },
    onUpdateMacroETiming: (Int, Int, Boolean) -> Unit = { _, _, _ -> },
    onToggleMacroG: (Boolean) -> Unit = {},
    onUpdateMacroGSize: (Int) -> Unit = {},
    onUpdateMacroGTransparency: (Float) -> Unit = {},
    onUpdateMacroGButtonPos: (Int, Int) -> Unit = { _, _ -> },
    onUpdateMacroGTargetPos: (Int, Int) -> Unit = { _, _ -> },
    onUpdateMacroGTiming: (Int, Int, Boolean) -> Unit = { _, _, _ -> }
) {
    var previewExpanded by remember { mutableStateOf(false) }

    val mockMetrics = remember {
        DeviceMetrics(
            fps = 60,
            frameTimeMs = 16.7f,
            displayHz = 120,
            cpuUsagePercent = 34,
            cpuClockGhz = 2.40f,
            ramUsedGb = 4.7f,
            ramTotalGb = 8.0f,
            batteryPercent = 82,
            isCharging = false,
            batteryTempC = 37.0f,
            rollingFps = listOf(58f, 59f, 60f, 60f, 59f, 60f, 60f, 60f, 58f, 60f),
            rollingFrameTime = listOf(17.2f, 16.9f, 16.6f, 16.6f, 16.9f, 16.6f, 16.6f, 16.6f, 17.2f, 16.6f)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("overlay_settings_screen")
    ) {
        Text(
            text = "OVERLAY HUD & MACRO CONFIG",
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Text(
            text = "Configure restore display, 15-style aim cursor, and [E] / [G] macro automation",
            color = TextSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Live Interactive Preview Box
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            glowAccent = true
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE INTERACTIVE PREVIEW",
                    color = NeonCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (previewExpanded) "Tap collapse inside" else "Tap pill to expand",
                    color = TextMuted,
                    fontSize = 9.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (previewExpanded) 360.dp else 90.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF030508))
                    .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                FloatingOverlayContent(
                    metrics = mockMetrics,
                    profile = profile,
                    logoBitmap = logoBitmap,
                    isExpanded = previewExpanded,
                    keyDurationText = "ACTIVE",
                    onToggleExpand = { previewExpanded = !previewExpanded },
                    onRestoreDisplayToggle = onRestoreDisplayToggle,
                    onForceRestoreAll = onForceRestoreAll,
                    onUpdateCrosshairOffset = onUpdateCrosshairOffset,
                    onUpdateCrosshairSize = { onUpdateCrosshairSettings(profile.crosshairStyle, profile.crosshairColor, it) },
                    onUpdateCrosshairStyle = { onUpdateCrosshairSettings(it, profile.crosshairColor, profile.crosshairSizeDp) },
                    onUpdateCrosshairColor = { onUpdateCrosshairSettings(profile.crosshairStyle, it, profile.crosshairSizeDp) },
                    onUpdateCrosshairTransparency = onUpdateCrosshairTransparency,
                    onUpdateCrosshairRotation = onUpdateCrosshairRotation,
                    onToggleCrosshair = { onToggleCrosshair(!profile.showCrosshair) },
                    onToggleMacroE = onToggleMacroE,
                    onUpdateMacroESize = onUpdateMacroESize,
                    onUpdateMacroETransparency = onUpdateMacroETransparency,
                    onUpdateMacroEButtonPos = onUpdateMacroEButtonPos,
                    onUpdateMacroETargetPos = onUpdateMacroETargetPos,
                    onUpdateMacroEInterval = { onUpdateMacroETiming(it, it, false) },
                    onToggleMacroG = onToggleMacroG,
                    onUpdateMacroGSize = onUpdateMacroGSize,
                    onUpdateMacroGTransparency = onUpdateMacroGTransparency,
                    onUpdateMacroGButtonPos = onUpdateMacroGButtonPos,
                    onUpdateMacroGTargetPos = onUpdateMacroGTargetPos,
                    onUpdateMacroGInterval = { onUpdateMacroGTiming(it, it, false) },
                    onUpdateMenuSize = onUpdateMenuSize,
                    onUpdateTransparency = onUpdateTransparency
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ==========================================
        // 1. RESTORE DISPLAY
        // ==========================================
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Restore, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                    Column {
                        Text(
                            text = "RESTORE DISPLAY",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (profile.restoreDisplayEnabled) "Auto-restores overlay elements when hidden/refreshed" else "Disabled",
                            color = if (profile.restoreDisplayEnabled) GamingGreen else TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                Switch(
                    checked = profile.restoreDisplayEnabled,
                    onCheckedChange = onRestoreDisplayToggle,
                    colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Preserves and restores size, position, transparency, rotation, color, and visibility state across app sessions and overlay minimizes without resetting configuration.",
                color = TextMuted,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Manual Force Restore Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x3300E5FF))
                    .border(0.8.dp, NeonCyan, RoundedCornerShape(8.dp))
                    .clickable { onForceRestoreAll() }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SYNC & RESTORE ALL OVERLAY ELEMENTS NOW",
                    color = NeonCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ==========================================
        // 2. AIM CURSOR / AIM MARKER (15 Styles, 22+ Colors, Rotation, Transparency, Directional controls)
        // ==========================================
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CropFree, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                    Column {
                        Text(
                            text = "AIM CURSOR / AIM MARKER",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "15 customizable styles, rotation, alpha, and D-pad position",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                Switch(
                    checked = profile.showCrosshair,
                    onCheckedChange = onToggleCrosshair,
                    colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                )
            }

            if (profile.showCrosshair) {
                Spacer(modifier = Modifier.height(14.dp))

                // 15 Style Selection with Live Preview
                Text(
                    text = "CURSOR STYLE (15 PRESETS):",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AimCursorRenderer.STYLES.forEach { styleInfo ->
                        val isSel = profile.crosshairStyle == styleInfo.key
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) NeonCyan.copy(alpha = 0.25f) else Color(0x221B273C))
                                .border(
                                    width = if (isSel) 1.4.dp else 0.8.dp,
                                    color = if (isSel) NeonCyan else Color(0x22FFFFFF),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    onUpdateCrosshairSettings(styleInfo.key, profile.crosshairColor, profile.crosshairSizeDp)
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                AimCursorPreview(
                                    style = styleInfo.key,
                                    color = Color(profile.crosshairColor),
                                    sizeDp = 18.dp,
                                    rotationDeg = profile.crosshairRotation,
                                    alpha = profile.crosshairTransparency
                                )
                                Column {
                                    Text(
                                        text = styleInfo.displayName,
                                        color = if (isSel) NeonCyan else Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = styleInfo.key,
                                        color = TextMuted,
                                        fontSize = 7.5.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 22+ Colors
                Text(
                    text = "CURSOR COLOR (22+ PALETTE):",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AimCursorRenderer.PALETTE_COLORS.forEach { (colorVal, _) ->
                        val isSel = profile.crosshairColor == colorVal
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(colorVal))
                                .border(
                                    width = if (isSel) 2.5.dp else 1.dp,
                                    color = if (isSel) Color.White else Color(0x33000000),
                                    shape = CircleShape
                                )
                                .clickable {
                                    onUpdateCrosshairSettings(profile.crosshairStyle, colorVal, profile.crosshairSizeDp)
                                }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Size Slider
                Text(
                    text = "Size: ${profile.crosshairSizeDp} dp",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = profile.crosshairSizeDp.toFloat(),
                    onValueChange = { onUpdateCrosshairSettings(profile.crosshairStyle, profile.crosshairColor, it.toInt()) },
                    valueRange = 12f..64f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )

                // Transparency Slider
                Text(
                    text = "Transparency: ${(profile.crosshairTransparency * 100).toInt()}%",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = profile.crosshairTransparency,
                    onValueChange = onUpdateCrosshairTransparency,
                    valueRange = 0.05f..1.0f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )

                // Rotation Slider
                Text(
                    text = "Rotation: ${profile.crosshairRotation.toInt()}°",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = profile.crosshairRotation,
                    onValueChange = onUpdateCrosshairRotation,
                    valueRange = 0f..360f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Directional Position Controller
                DirectionalPositionController(
                    title = "Aim Marker Position",
                    x = profile.crosshairOffsetX,
                    y = profile.crosshairOffsetY,
                    defaultX = 0,
                    defaultY = 0,
                    minX = -800,
                    maxX = 800,
                    minY = -800,
                    maxY = 800,
                    onPositionChange = onUpdateCrosshairOffset
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ==========================================
        // 3. MACRO [E] BUTTON
        // ==========================================
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Keyboard, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                    Column {
                        Text(
                            text = "MACRO [E] BUTTON",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Configurable repeated-touch button with target locator",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                Switch(
                    checked = profile.macroEEnabled,
                    onCheckedChange = onToggleMacroE,
                    colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                )
            }

            if (profile.macroEEnabled) {
                Spacer(modifier = Modifier.height(14.dp))

                // Size Presets & Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Button Size: ${profile.macroESizeDp} dp", color = TextPrimary, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PresetSizeButton("SMALL", 40, profile.macroESizeDp == 40) { onUpdateMacroESize(40) }
                        PresetSizeButton("MEDIUM", 48, profile.macroESizeDp == 48) { onUpdateMacroESize(48) }
                    }
                }
                Slider(
                    value = profile.macroESizeDp.toFloat(),
                    onValueChange = { onUpdateMacroESize(it.toInt()) },
                    valueRange = 32f..72f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )

                // Transparency Slider
                Text(
                    text = "Transparency: ${(profile.macroETransparency * 100).toInt()}%",
                    color = TextPrimary,
                    fontSize = 11.sp
                )
                Slider(
                    value = profile.macroETransparency,
                    onValueChange = onUpdateMacroETransparency,
                    valueRange = 0.1f..1.0f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Timing Row (Tap Speed & Retap Speed)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TimingEditorBox(
                        label = "TAP SPEED",
                        speedMs = profile.macroETapSpeedMs,
                        explanation = "Tap Speed = delay/timing used for the initial action.",
                        onSpeedChange = { onUpdateMacroETiming(it, profile.macroERetapSpeedMs, profile.macroELoop) },
                        modifier = Modifier.weight(1f)
                    )
                    TimingEditorBox(
                        label = "RETAP SPEED",
                        speedMs = profile.macroERetapSpeedMs,
                        explanation = "Retap Speed = delay between repeated actions.",
                        onSpeedChange = { onUpdateMacroETiming(profile.macroETapSpeedMs, it, profile.macroELoop) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Repeat Loop Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("REPEAT LOOP", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Repeats touches continuously until released", color = TextMuted, fontSize = 9.sp)
                    }
                    Switch(
                        checked = profile.macroELoop,
                        onCheckedChange = { onUpdateMacroETiming(profile.macroETapSpeedMs, profile.macroERetapSpeedMs, it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Target Position
                DirectionalPositionController(
                    title = "[E] Target Position",
                    x = profile.macroETargetX,
                    y = profile.macroETargetY,
                    defaultX = 540,
                    defaultY = 960,
                    minX = 0,
                    maxX = 2500,
                    minY = 0,
                    maxY = 3500,
                    onPositionChange = onUpdateMacroETargetPos
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Button Position
                DirectionalPositionController(
                    title = "[E] Button Position",
                    x = profile.macroEPosX,
                    y = profile.macroEPosY,
                    defaultX = 120,
                    defaultY = 400,
                    minX = 0,
                    maxX = 2500,
                    minY = 0,
                    maxY = 3500,
                    onPositionChange = onUpdateMacroEButtonPos
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ==========================================
        // 4. MACRO [G] BUTTON
        // ==========================================
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Keyboard, contentDescription = null, tint = GamingAmber, modifier = Modifier.size(20.dp))
                    Column {
                        Text(
                            text = "MACRO [G] BUTTON",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Configurable independent repeated-touch button [G]",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                Switch(
                    checked = profile.macroGEnabled,
                    onCheckedChange = onToggleMacroG,
                    colors = SwitchDefaults.colors(checkedThumbColor = GamingAmber)
                )
            }

            if (profile.macroGEnabled) {
                Spacer(modifier = Modifier.height(14.dp))

                // Size Presets & Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Button Size: ${profile.macroGSizeDp} dp", color = TextPrimary, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PresetSizeButton("MEDIUM", 56, profile.macroGSizeDp == 56, accentColor = GamingAmber) { onUpdateMacroGSize(56) }
                        PresetSizeButton("LARGE", 72, profile.macroGSizeDp == 72, accentColor = GamingAmber) { onUpdateMacroGSize(72) }
                    }
                }
                Slider(
                    value = profile.macroGSizeDp.toFloat(),
                    onValueChange = { onUpdateMacroGSize(it.toInt()) },
                    valueRange = 40f..88f,
                    colors = SliderDefaults.colors(thumbColor = GamingAmber, activeTrackColor = GamingAmber)
                )

                // Transparency Slider
                Text(
                    text = "Transparency: ${(profile.macroGTransparency * 100).toInt()}%",
                    color = TextPrimary,
                    fontSize = 11.sp
                )
                Slider(
                    value = profile.macroGTransparency,
                    onValueChange = onUpdateMacroGTransparency,
                    valueRange = 0.1f..1.0f,
                    colors = SliderDefaults.colors(thumbColor = GamingAmber, activeTrackColor = GamingAmber)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Timing Row (Tap Speed & Retap Speed)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TimingEditorBox(
                        label = "TAP SPEED",
                        speedMs = profile.macroGTapSpeedMs,
                        explanation = "Tap Speed = delay/timing used for the initial action.",
                        accentColor = GamingAmber,
                        onSpeedChange = { onUpdateMacroGTiming(it, profile.macroGRetapSpeedMs, profile.macroGLoop) },
                        modifier = Modifier.weight(1f)
                    )
                    TimingEditorBox(
                        label = "RETAP SPEED",
                        speedMs = profile.macroGRetapSpeedMs,
                        explanation = "Retap Speed = delay between repeated actions.",
                        accentColor = GamingAmber,
                        onSpeedChange = { onUpdateMacroGTiming(profile.macroGTapSpeedMs, it, profile.macroGLoop) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Repeat Loop Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("REPEAT LOOP", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Repeats touches continuously until released", color = TextMuted, fontSize = 9.sp)
                    }
                    Switch(
                        checked = profile.macroGLoop,
                        onCheckedChange = { onUpdateMacroGTiming(profile.macroGTapSpeedMs, profile.macroGRetapSpeedMs, it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = GamingAmber)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Target Position
                DirectionalPositionController(
                    title = "[G] Target Position",
                    x = profile.macroGTargetX,
                    y = profile.macroGTargetY,
                    defaultX = 540,
                    defaultY = 1100,
                    minX = 0,
                    maxX = 2500,
                    minY = 0,
                    maxY = 3500,
                    onPositionChange = onUpdateMacroGTargetPos
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Button Position
                DirectionalPositionController(
                    title = "[G] Button Position",
                    x = profile.macroGPosX,
                    y = profile.macroGPosY,
                    defaultX = 120,
                    defaultY = 520,
                    minX = 0,
                    maxX = 2500,
                    minY = 0,
                    maxY = 3500,
                    onPositionChange = onUpdateMacroGButtonPos
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // HUD Appearance Customization
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "HUD SCALING & GLASS THEME",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Adjust floating telemetry HUD dimension and transparency",
                color = TextMuted,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text("HUD Scale: ${(profile.overlayScale * 100).toInt()}%", color = TextSecondary, fontSize = 10.sp)
            Slider(
                value = profile.overlayScale,
                onValueChange = onUpdateScale,
                valueRange = 0.7f..1.4f,
                colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
            )

            Text("Overlay Menu Size: ${(profile.expandedMenuSize * 100).toInt()}%", color = TextSecondary, fontSize = 10.sp)
            Slider(
                value = profile.expandedMenuSize,
                onValueChange = onUpdateMenuSize,
                valueRange = 0.65f..1.4f,
                colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
            )

            Text("Glass Opacity: ${(profile.glassTransparency * 100).toInt()}%", color = TextSecondary, fontSize = 10.sp)
            Slider(
                value = profile.glassTransparency,
                onValueChange = {
                    onUpdateTransparency(it)
                    onUpdateAlpha(it)
                },
                valueRange = 0.2f..0.95f,
                colors = SliderDefaults.colors(thumbColor = GamingAmber, activeTrackColor = GamingAmber)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Telemetry Metrics Toggles
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "ACTIVE TELEMETRY METRICS",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                MetricFilterChip("FPS", profile.showFps) { onToggleMetric("fps", it) }
                MetricFilterChip("Frame Time", profile.showFrameTime) { onToggleMetric("frame_time", it) }
                MetricFilterChip("CPU Usage", profile.showCpu) { onToggleMetric("cpu", it) }
                MetricFilterChip("CPU Clock", profile.showClock) { onToggleMetric("clock", it) }
                MetricFilterChip("RAM", profile.showRam) { onToggleMetric("ram", it) }
                MetricFilterChip("Temperature", profile.showTemp) { onToggleMetric("temp", it) }
                MetricFilterChip("Battery", profile.showBattery) { onToggleMetric("battery", it) }
                MetricFilterChip("Display Hz", profile.showDisplayHz) { onToggleMetric("display", it) }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun MetricFilterChip(
    label: String,
    isSelected: Boolean,
    onToggle: (Boolean) -> Unit
) {
    FilterChip(
        selected = isSelected,
        onClick = { onToggle(!isSelected) },
        label = {
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = NeonCyan.copy(alpha = 0.25f),
            selectedLabelColor = NeonCyan,
            containerColor = Color(0x221E293B),
            labelColor = TextMuted
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = isSelected,
            borderColor = if (isSelected) NeonCyan else Color(0x22FFFFFF),
            borderWidth = 0.8.dp
        )
    )
}
