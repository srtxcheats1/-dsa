package com.srtxcheats.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.srtxcheats.ui.theme.NeonCyan
import com.srtxcheats.ui.theme.TextMuted
import com.srtxcheats.ui.theme.TextPrimary
import com.srtxcheats.ui.theme.TextSecondary

/**
 * DirectionalPositionController:
 * Precision D-Pad & fine-stepping controller for overlay coordinates.
 * Provides LEFT/RIGHT/UP/DOWN and fine-step [-10, -1, +1, +10] for both axes,
 * live readout, and one-tap reset.
 */
@Composable
fun DirectionalPositionController(
    title: String,
    x: Int,
    y: Int,
    defaultX: Int = 0,
    defaultY: Int = 0,
    minX: Int = -1200,
    maxX: Int = 1600,
    minY: Int = -1200,
    maxY: Int = 2600,
    stepSize: Int = 5,
    onPositionChange: (newX: Int, newY: Int) -> Unit,
    onReset: () -> Unit = { onPositionChange(defaultX, defaultY) },
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(0.8.dp, Color(0x3300E5FF), RoundedCornerShape(12.dp))
            .testTag("position_controller_${title.lowercase().replace(' ', '_')}"),
        color = Color(0x220A101C),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            // Header: Title & Readout & Reset
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = title.uppercase(),
                        color = NeonCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "X = $x   Y = $y",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Reset Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x33FF5252))
                        .border(0.6.dp, Color(0x66FF5252), RoundedCornerShape(6.dp))
                        .clickable { onReset() }
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset Position",
                            tint = Color(0xFFFF8A80),
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "RESET",
                            color = Color(0xFFFF8A80),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Main Directional Controls Row (D-Pad + Fine Controls)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // D-Pad Cross
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(4.dp)
                ) {
                    // UP
                    DirectionButton(
                        icon = Icons.Default.KeyboardArrowUp,
                        label = "UP",
                        onClick = {
                            val newY = (y - stepSize).coerceIn(minY, maxY)
                            onPositionChange(x, newY)
                        }
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // LEFT
                        DirectionButton(
                            icon = Icons.Default.KeyboardArrowLeft,
                            label = "LEFT",
                            onClick = {
                                val newX = (x - stepSize).coerceIn(minX, maxX)
                                onPositionChange(newX, y)
                            }
                        )
                        // Center Pip
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0x2200E5FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(NeonCyan)
                            )
                        }
                        // RIGHT
                        DirectionButton(
                            icon = Icons.Default.KeyboardArrowRight,
                            label = "RIGHT",
                            onClick = {
                                val newX = (x + stepSize).coerceIn(minX, maxX)
                                onPositionChange(newX, y)
                            }
                        )
                    }
                    // DOWN
                    DirectionButton(
                        icon = Icons.Default.KeyboardArrowDown,
                        label = "DOWN",
                        onClick = {
                            val newY = (y + stepSize).coerceIn(minY, maxY)
                            onPositionChange(x, newY)
                        }
                    )
                }

                // Fine Controls (X and Y precise buttons)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Fine X
                    Text(
                        text = "X ADJUST: $x",
                        color = TextSecondary,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        listOf(-10, -1, 1, 10).forEach { delta ->
                            FineStepButton(
                                delta = delta,
                                onClick = {
                                    val newX = (x + delta).coerceIn(minX, maxX)
                                    onPositionChange(newX, y)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Fine Y
                    Text(
                        text = "Y ADJUST: $y",
                        color = TextSecondary,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        listOf(-10, -1, 1, 10).forEach { delta ->
                            FineStepButton(
                                delta = delta,
                                onClick = {
                                    val newY = (y + delta).coerceIn(minY, maxY)
                                    onPositionChange(x, newY)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0x33101C30))
            .border(0.8.dp, Color(0x4400E5FF), RoundedCornerShape(6.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = NeonCyan,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun FineStepButton(
    delta: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPositive = delta > 0
    val text = if (isPositive) "+$delta" else "$delta"
    val accentColor = if (isPositive) NeonCyan else Color(0xFFFFB300)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(5.dp))
            .background(Color(0x221A263C))
            .border(0.6.dp, accentColor.copy(alpha = 0.6f), RoundedCornerShape(5.dp))
            .clickable { onClick() }
            .padding(vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = accentColor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
