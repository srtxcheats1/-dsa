package com.srtxcheats.ui.overlay

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.srtxcheats.ui.theme.NeonCyan

/**
 * Unified Aim Marker overlay.
 *
 * Supports 15 cursor styles, custom rotation, transparency, size, and
 * fine position coordinates.
 *
 * BEHAVIOR SPECIFICATION:
 * - CALIBRATION ON:
 *     Aim Marker = draggable
 *     Aim Marker border = visible (bounding box with coordinates)
 *     Position can be adjusted to match game crosshairs
 * - CALIBRATION OFF (Gameplay):
 *     Aim Marker = locked
 *     Aim Marker border = hidden
 *     Aim Marker cannot move
 *     Touch pass-through (FLAG_NOT_TOUCHABLE window)
 */
@Composable
fun ScreenMarkerOverlay(
    style: String = "CROSS",
    colorLong: Long = 0xFF00E5FF,
    sizeDp: Int = 24,
    transparency: Float = 1.0f,
    rotation: Float = 0f,
    offsetX: Int = 0,
    offsetY: Int = 0,
    isCalibrating: Boolean = false,
    onDragDelta: (dx: Float, dy: Float) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val markerColor = Color(colorLong)

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        val targetModifier = if (isCalibrating) {
            Modifier
                .offset { IntOffset(offsetX, offsetY) }
                .size((sizeDp + 24).dp)
                .pointerInput(isCalibrating) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x, dragAmount.y)
                    }
                }
        } else {
            Modifier
                .offset { IntOffset(offsetX, offsetY) }
                .size(sizeDp.dp)
        }

        Box(
            modifier = targetModifier,
            contentAlignment = Alignment.Center
        ) {
            // ============================================================
            // 1. EDITING BORDER (VISIBLE ONLY WHILE CALIBRATING)
            // ============================================================
            if (isCalibrating) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .border(1.5.dp, NeonCyan.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                )

                Text(
                    text = "AIM ($offsetX, $offsetY)",
                    color = NeonCyan,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-7).dp)
                        .background(Color(0xEE050B14), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }

            // ============================================================
            // 2. AIM MARKER CROSSHAIR CANVAS (WITH 15 STYLES, ROTATION, TRANSPARENCY)
            // ============================================================
            Canvas(modifier = Modifier.size(sizeDp.dp)) {
                AimCursorRenderer.drawCursor(
                    drawScope = this,
                    style = style,
                    color = markerColor,
                    rotationDeg = rotation,
                    alpha = transparency
                )
            }
        }
    }
}
