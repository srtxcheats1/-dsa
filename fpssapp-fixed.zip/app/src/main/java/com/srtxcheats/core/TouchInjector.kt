package com.srtxcheats.core

import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.view.InputEvent
import android.view.MotionEvent
import com.srtxcheats.utils.AppLogger
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.io.OutputStream
import java.lang.reflect.Method

/**
 * TouchInjector — fast touch dispatch for the Macro [E] / [G] buttons.
 *
 * WHY THE OLD VERSION ONLY "ANIMATED":
 *   It launched a brand-new `sh -c "input tap x y"` process for EVERY tap. Each launch costs
 *   100-300 ms, so the 5-100 ms interval was never reached, and any failure was silently ignored.
 *
 * NEW ENGINE (two paths, auto-selected):
 *   1. FAST  — Shizuku binder -> IInputManager.injectInputEvent(). Sub-millisecond, true ms-timing.
 *   2. SLOW  — one persistent shell (Shizuku or su) that receives `input tap x y &` lines.
 *              Used only if the fast path is unavailable on this ROM.
 */
object TouchInjector {

    private const val INJECT_MODE_ASYNC = 0
    private const val SOURCE_TOUCHSCREEN = 0x00001002   // InputDevice.SOURCE_TOUCHSCREEN

    // ── fast path state ────────────────────────────────────────────
    private var inputService: Any? = null
    private var injectMethod: Method? = null
    private var setSourceMethod: Method? = null
    @Volatile private var fastTried = false
    @Volatile var fastReady = false
        private set

    // ── slow path state ────────────────────────────────────────────
    private var shellProcess: Process? = null
    private var shellOut: OutputStream? = null
    private var shellIsShizuku = false

    @Volatile var lastError: String? = null
        private set

    /** Try to prepare the fast path. Safe to call repeatedly. */
    @Synchronized
    fun prepareFast(): Boolean {
        if (fastReady) return true
        if (fastTried) return false
        fastTried = true
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
            }
            val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            val ifaceClass = Class.forName("android.hardware.input.IInputManager")
            val stubClass  = Class.forName("android.hardware.input.IInputManager\$Stub")
            val asInterface = stubClass.getMethod("asInterface", IBinder::class.java)
            inputService = asInterface.invoke(null, binder)
            injectMethod = ifaceClass.getMethod(
                "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
            )
            setSourceMethod = InputEvent::class.java.getMethod(
                "setSource", Int::class.javaPrimitiveType
            )
            fastReady = true
            AppLogger.i("TouchInjector: fast binder path READY")
            true
        } catch (t: Throwable) {
            lastError = "Fast touch path unavailable: ${t.javaClass.simpleName}: ${t.message}"
            AppLogger.w(lastError ?: "fast path failed")
            false
        }
    }

    /** One tap through the fast path. Returns true if Android accepted both events. */
    fun fastTap(x: Int, y: Int): Boolean {
        val svc = inputService ?: return false
        val inject = injectMethod ?: return false
        val setSrc = setSourceMethod ?: return false
        val downTime = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x.toFloat(), y.toFloat(), 0)
        val up   = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x.toFloat(), y.toFloat(), 0)
        return try {
            setSrc.invoke(down, SOURCE_TOUCHSCREEN)
            setSrc.invoke(up, SOURCE_TOUCHSCREEN)
            val ok1 = inject.invoke(svc, down, INJECT_MODE_ASYNC) as? Boolean ?: false
            val ok2 = inject.invoke(svc, up, INJECT_MODE_ASYNC) as? Boolean ?: false
            ok1 && ok2
        } catch (t: Throwable) {
            lastError = "Touch injection failed: ${t.cause?.message ?: t.message}"
            false
        } finally {
            down.recycle(); up.recycle()
        }
    }

    /** One tap through a persistent shell (does not wait; taps overlap in background). */
    @Synchronized
    fun shellTap(x: Int, y: Int, viaShizuku: Boolean): Boolean {
        return try {
            val alive = shellProcess?.let { p ->
                try { p.exitValue(); false } catch (_: IllegalThreadStateException) { true }
            } ?: false
            if (!alive || shellIsShizuku != viaShizuku) {
                closeShell()
                shellProcess = if (viaShizuku) Shizuku.newProcess(arrayOf("sh"), null, null)
                               else Runtime.getRuntime().exec("su")
                shellOut = shellProcess!!.outputStream
                shellIsShizuku = viaShizuku
            }
            shellOut!!.write("input tap $x $y &\n".toByteArray())
            shellOut!!.flush()
            true
        } catch (t: Throwable) {
            lastError = "Shell tap failed: ${t.message}"
            closeShell()
            false
        }
    }

    /** Synchronous single tap that returns the real shell result — used for diagnostics. */
    suspend fun diagnoseTap(x: Int, y: Int, viaShizuku: Boolean): String? {
        val res = if (viaShizuku) ShizukuManager.executeCommand("input tap $x $y")
                  else RootExecutor.executeCommand("input tap $x $y")
        if (res.exitCode == 0 && !res.error.contains("Exception", true)) return null
        val msg = (res.error + " " + res.output)
        return if (msg.contains("INJECT_EVENTS", true) || msg.contains("SecurityException", true))
            "Blocked by system: enable 'USB debugging (Security settings)' / 'Allow simulated input' in Developer options"
        else "Tap command failed: ${msg.trim().take(80)}"
    }

    @Synchronized
    fun closeShell() {
        try { shellOut?.close() } catch (_: Throwable) {}
        try { shellProcess?.destroy() } catch (_: Throwable) {}
        shellOut = null; shellProcess = null
    }
}
