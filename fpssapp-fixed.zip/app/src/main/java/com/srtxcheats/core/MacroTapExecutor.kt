package com.srtxcheats.core

import com.srtxcheats.model.GameProfile
import com.srtxcheats.utils.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * MacroTapExecutor — press-and-hold "crazy tap" for Macro [E] and Macro [G].
 *
 * - Holding the button  -> taps the target point repeatedly every `macro*TapSpeedMs` ms.
 * - Releasing the button -> stops immediately.
 * - E and G run independently.
 * - Uses TouchInjector (fast Shizuku binder injection, with persistent-shell fallback).
 * - Real errors are reported through onStatus (always on the main thread via the service).
 */
object MacroTapExecutor {

    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private var macroEJob: Job? = null
    private var macroGJob: Job? = null

    private val _isERunning = MutableStateFlow(false)
    val isERunning: StateFlow<Boolean> = _isERunning.asStateFlow()

    private val _isGRunning = MutableStateFlow(false)
    val isGRunning: StateFlow<Boolean> = _isGRunning.asStateFlow()

    private val _permissionStatus = MutableStateFlow<String?>(null)
    val permissionStatus: StateFlow<String?> = _permissionStatus.asStateFlow()

    // ───────────────────────── E ─────────────────────────
    @Synchronized
    fun startMacroE(profile: GameProfile, onPulse: () -> Unit = {}, onStatus: (String) -> Unit = {}) =
        startMacroE(profileProvider = { profile }, onPulse = onPulse, onStatus = onStatus)

    @Synchronized
    fun startMacroE(
        profileProvider: () -> GameProfile,
        onPulse: () -> Unit = {},
        onStatus: (String) -> Unit = {}
    ) {
        if (_isERunning.value && macroEJob?.isActive == true) return
        if (!privilegeOk("E", onStatus)) return
        _isERunning.value = true
        macroEJob = launchLoop(
            name = "E", onPulse = onPulse, onStatus = onStatus,
            read = { p -> Triple(p.macroETargetX, p.macroETargetY, p.macroETapSpeedMs) },
            profileProvider = profileProvider,
            onFinished = { _isERunning.value = false }
        )
    }

    @Synchronized
    fun stopMacroE() {
        macroEJob?.cancel(); macroEJob = null
        _isERunning.value = false
    }

    // ───────────────────────── G ─────────────────────────
    @Synchronized
    fun startMacroG(profile: GameProfile, onPulse: () -> Unit = {}, onStatus: (String) -> Unit = {}) =
        startMacroG(profileProvider = { profile }, onPulse = onPulse, onStatus = onStatus)

    @Synchronized
    fun startMacroG(
        profileProvider: () -> GameProfile,
        onPulse: () -> Unit = {},
        onStatus: (String) -> Unit = {}
    ) {
        if (_isGRunning.value && macroGJob?.isActive == true) return
        if (!privilegeOk("G", onStatus)) return
        _isGRunning.value = true
        macroGJob = launchLoop(
            name = "G", onPulse = onPulse, onStatus = onStatus,
            read = { p -> Triple(p.macroGTargetX, p.macroGTargetY, p.macroGTapSpeedMs) },
            profileProvider = profileProvider,
            onFinished = { _isGRunning.value = false }
        )
    }

    @Synchronized
    fun stopMacroG() {
        macroGJob?.cancel(); macroGJob = null
        _isGRunning.value = false
    }

    @Synchronized
    fun cancelAll() {
        stopMacroE()
        stopMacroG()
        TouchInjector.closeShell()
    }

    // ───────────────────────── internals ─────────────────────────
    private fun privilegeOk(name: String, onStatus: (String) -> Unit): Boolean {
        if (ShizukuManager.isAuthorized() || RootExecutor.isRootAvailable()) return true
        val msg = "Touch dispatch requires Shizuku (running + permission granted) or Root"
        _permissionStatus.value = msg
        onStatus(msg)
        AppLogger.w("Macro [$name] unavailable: Shizuku / Root not authorized")
        return false
    }

    private fun launchLoop(
        name: String,
        onPulse: () -> Unit,
        onStatus: (String) -> Unit,
        read: (GameProfile) -> Triple<Int, Int, Int>,
        profileProvider: () -> GameProfile,
        onFinished: () -> Unit
    ): Job = scope.launch {
        val viaShizuku = ShizukuManager.isAuthorized()
        var useFast = viaShizuku && TouchInjector.prepareFast()
        var failStreak = 0
        var reported = false

        try {
            // One-time real check so permission problems are shown instead of silently ignored
            if (!useFast) {
                val (x0, y0, _) = read(profileProvider())
                TouchInjector.diagnoseTap(x0.coerceAtLeast(0), y0.coerceAtLeast(0), viaShizuku)?.let {
                    onStatus(it); reported = true
                }
            }

            while (isActive) {
                val (tx, ty, speed) = read(profileProvider())      // re-read every tap → live settings
                val x = tx.coerceAtLeast(0)
                val y = ty.coerceAtLeast(0)
                // fast path honours the ms value; shell fallback can't go below ~30 ms
                val interval = speed.coerceAtLeast(if (useFast) 1 else 30).toLong()

                val ok = if (useFast) TouchInjector.fastTap(x, y)
                         else TouchInjector.shellTap(x, y, viaShizuku)

                if (ok) {
                    failStreak = 0
                    onPulse()
                } else if (++failStreak >= 3) {
                    if (useFast) {
                        // injection rejected → fall back to the shell path
                        AppLogger.w("Macro [$name] fast path failed, switching to shell: ${TouchInjector.lastError}")
                        useFast = false
                        failStreak = 0
                        TouchInjector.diagnoseTap(x, y, viaShizuku)?.let { onStatus(it); reported = true }
                    } else {
                        if (!reported) onStatus(TouchInjector.lastError ?: "Tap failed")
                        reported = true
                        break
                    }
                }
                delay(interval)
            }
        } finally {
            onFinished()
        }
    }
}
