package com.srtxcheats.core

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.srtxcheats.utils.AppLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * GameBooster:
 * Legitimate background application optimization for gaming sessions.
 * Stops eligible background processes without terminating the target game,
 * system server, or SRT X CHEATS.
 *
 * Never outputs fake success messages. Reports real state and required permissions.
 */
object GameBooster {

    data class GameBoostResult(
        val isSuccess: Boolean,
        val closedCount: Int,
        val message: String,
        val requiresPermission: Boolean = false
    )

    private val CRITICAL_SYSTEM_PACKAGES = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.google.android.inputmethod.latin"
    )

    suspend fun performGameBoost(context: Context, targetGamePackage: String): GameBoostResult = withContext(Dispatchers.IO) {
        val myPkg = context.packageName
        val isAuthorized = ShizukuManager.isAuthorized()
        val isRoot = RootExecutor.isRootAvailable()

        if (!isAuthorized && !isRoot) {
            return@withContext GameBoostResult(
                isSuccess = false,
                closedCount = 0,
                message = "Game Boost unavailable — permission required",
                requiresPermission = true
            )
        }

        var closedCount = 0
        val pm = context.packageManager

        try {
            val installedPackages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(0)
            }

            for (pkg in installedPackages) {
                val pkgName = pkg.packageName
                // NEVER kill ourselves, the target game, or core system components
                if (pkgName == myPkg) continue
                if (pkgName.equals(targetGamePackage, ignoreCase = true)) continue
                if (CRITICAL_SYSTEM_PACKAGES.contains(pkgName)) continue

                val appInfo = pkg.applicationInfo ?: continue
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                if (isSystem) continue

                // Eligible third-party background application
                val stopCmd = "am force-stop $pkgName"
                val res = if (isAuthorized) {
                    ShizukuManager.executeCommand(stopCmd)
                } else {
                    RootExecutor.executeCommand(stopCmd)
                }

                if (res.exitCode == 0) {
                    closedCount++
                }
            }
        } catch (e: Exception) {
            AppLogger.e("Error during Game Boost execution: ${e.message}", e)
        }

        AppLogger.i("Game Boost finished. Closed $closedCount background applications for $targetGamePackage.")
        GameBoostResult(
            isSuccess = true,
            closedCount = closedCount,
            message = "Game Boost Active: Stopped $closedCount background apps",
            requiresPermission = false
        )
    }
}
