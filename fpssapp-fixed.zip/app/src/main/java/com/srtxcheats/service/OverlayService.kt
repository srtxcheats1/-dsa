package com.srtxcheats.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.srtxcheats.MainActivity
import com.srtxcheats.R
import com.srtxcheats.core.GameBooster
import com.srtxcheats.core.GameDetector
import com.srtxcheats.core.MacroTapExecutor
import com.srtxcheats.core.PerformanceMonitor
import com.srtxcheats.core.RamBooster
import com.srtxcheats.data.DataStoreManager
import com.srtxcheats.data.LogoHelper
import com.srtxcheats.display.DisplayBackupManager
import com.srtxcheats.display.DisplayCommandExecutor
import com.srtxcheats.keySystem.KeyRepository
import com.srtxcheats.model.GameProfile
import com.srtxcheats.ui.overlay.FloatingOverlayContent
import com.srtxcheats.ui.overlay.MacroOverlayButton
import com.srtxcheats.ui.overlay.ScreenMarkerOverlay
import com.srtxcheats.utils.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * OverlayService:
 * Foreground service hosting:
 * 1. Compact / Expanded liquid-glass gaming HUD with RAM Clean & Game Boost
 * 2. Visual aim marker overlay (15 styles, custom rotation, transparency, size & coordinates)
 * 3. Fixed circular [E] and [G] press-and-hold trigger buttons (no on-screen target circles)
 * 4. Automatic restoration of original phone settings on cancel / close
 */
class OverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "srt_gaming_monitor_channel"
        const val NOTIFICATION_ID = 101

        const val ACTION_START = "com.srtxcheats.service.ACTION_START"
        const val ACTION_STOP = "com.srtxcheats.service.ACTION_STOP"
        const val ACTION_RESTORE_DISPLAY = "com.srtxcheats.service.ACTION_RESTORE_DISPLAY"
        const val ACTION_GAME_BOOST = "com.srtxcheats.service.ACTION_GAME_BOOST"
        const val ACTION_RAM_BOOST = "com.srtxcheats.service.ACTION_RAM_BOOST"

        @Volatile
        var isServiceRunning = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, OverlayService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, OverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun restoreDisplays(context: Context) {
            val intent = Intent(context, OverlayService::class.java).apply {
                action = ACTION_RESTORE_DISPLAY
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var dataStoreManager: DataStoreManager
    private lateinit var performanceMonitor: PerformanceMonitor
    private lateinit var windowManager: WindowManager
    private lateinit var displayBackupManager: DisplayBackupManager

    // Windows
    private var overlayView: ComposeView? = null
    private var markerView: ComposeView? = null
    private var macroEView: ComposeView? = null
    private var macroGView: ComposeView? = null

    private var overlayParams: WindowManager.LayoutParams? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var macroEParams: WindowManager.LayoutParams? = null
    private var macroGParams: WindowManager.LayoutParams? = null

    private val lifecycleOwner = ServiceLifecycleOwner()
    private var isExpanded by mutableStateOf(false)
    private var currentProfile by mutableStateOf(GameProfile.defaultFor("", "Free Fire MAX"))
    private lateinit var keyRepository: KeyRepository

    override fun onCreate() {
        super.onCreate()
        com.srtxcheats.security.IntegrityProtectionManager.verifyAppIntegrity(this)
        lifecycleOwner.onCreate()
        lifecycleOwner.onStart()

        dataStoreManager = DataStoreManager(this)
        performanceMonitor = PerformanceMonitor(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        keyRepository = KeyRepository(this)
        displayBackupManager = DisplayBackupManager(this)

        createNotificationChannel()
        startForegroundNotification()

        isServiceRunning = true
        performanceMonitor.startMonitoring(1000L)

        // License expiry watcher
        serviceScope.launch(Dispatchers.IO) {
            while (isActive) {
                val session = keyRepository.getCachedSession()
                if (keyRepository.isSessionExpired(session)) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@OverlayService, "License key expired! Closing overlay and app.", Toast.LENGTH_LONG).show()
                        try {
                            val exitIntent = Intent(this@OverlayService, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                                putExtra("KEY_EXPIRED", true)
                            }
                            startActivity(exitIntent)
                        } catch (_: Exception) {}
                        stopSelf()
                    }
                    break
                }
                delay(3000)
            }
        }

        // Observe profile updates
        serviceScope.launch {
            dataStoreManager.gameProfileFlow.collectLatest { profile ->
                currentProfile = profile
                updateOverlayWindowAttributes(profile)
                updateMarkerOverlay(profile)
                updateMacroEOverlay(profile)
                updateMacroGOverlay(profile)
            }
        }

        // Background monitor for selected game auto-management
        serviceScope.launch(Dispatchers.IO) {
            while (isActive) {
                val fgPkg = GameDetector.getForegroundPackageName(this@OverlayService)
                val isGame = fgPkg != null && (fgPkg == currentProfile.packageName || GameDetector.POPULAR_GAME_PACKAGES.contains(fgPkg))
                if (isGame && !currentProfile.isGameBoostActive) {
                    dataStoreManager.setGameBoostActive(true)
                }
                delay(2500)
            }
        }

        setupOverlayView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                performFullCleanupAndStop()
                return START_NOT_STICKY
            }
            ACTION_RESTORE_DISPLAY -> {
                restoreAllDisplays()
            }
            ACTION_RAM_BOOST -> {
                serviceScope.launch {
                    val boostResult = RamBooster.performBoost(this@OverlayService)
                    dataStoreManager.saveLastRamFreedMb(boostResult.freedMb)
                }
            }
            ACTION_GAME_BOOST -> {
                serviceScope.launch {
                    val boostRes = GameBooster.performGameBoost(this@OverlayService, currentProfile.packageName)
                    if (boostRes.isSuccess) {
                        dataStoreManager.setGameBoostActive(true)
                    }
                }
            }
        }
        return START_STICKY
    }

    private fun setupOverlayView() {
        if (overlayView != null) return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = currentProfile.overlayPosX
            y = currentProfile.overlayPosY
        }
        overlayParams = params

        val logoBitmap = LogoHelper.getLogoBitmap(this)

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                val metrics by performanceMonitor.metrics.collectAsState()
                val sessionState by keyRepository.licenseSessionFlow.collectAsState(initial = com.srtxcheats.keySystem.LicenseSession.EMPTY)
                val durationText = keyRepository.formatRemainingDuration(sessionState)

                FloatingOverlayContent(
                    metrics = metrics,
                    profile = currentProfile,
                    logoBitmap = logoBitmap,
                    isExpanded = isExpanded,
                    keyDurationText = durationText,
                    onToggleExpand = {
                        isExpanded = !isExpanded
                    },
                    onDragDelta = { dx, dy ->
                        params.x = (params.x + dx.toInt()).coerceAtLeast(0)
                        params.y = (params.y + dy.toInt()).coerceAtLeast(0)
                        try {
                            windowManager.updateViewLayout(this, params)
                        } catch (_: Exception) {}
                        serviceScope.launch {
                            dataStoreManager.saveOverlayPosition(params.x, params.y)
                        }
                    },
                    onRestoreDisplayToggle = { enabled ->
                        serviceScope.launch {
                            dataStoreManager.saveRestoreDisplay(enabled)
                            if (enabled) {
                                restoreAllDisplays()
                            }
                        }
                    },
                    onForceRestoreAll = {
                        restoreAllDisplays()
                    },
                    onUpdateCrosshairOffset = { x, y ->
                        serviceScope.launch {
                            dataStoreManager.saveCrosshairOffset(x, y)
                        }
                    },
                    onUpdateCrosshairSize = { size ->
                        serviceScope.launch {
                            dataStoreManager.saveCrosshairSize(size)
                        }
                    },
                    onUpdateCrosshairStyle = { style ->
                        serviceScope.launch {
                            dataStoreManager.saveCrosshairStyle(style)
                        }
                    },
                    onUpdateCrosshairColor = { color ->
                        serviceScope.launch {
                            dataStoreManager.saveCrosshairSettings(currentProfile.crosshairStyle, color)
                        }
                    },
                    onUpdateCrosshairTransparency = { trans ->
                        serviceScope.launch {
                            dataStoreManager.saveCrosshairTransparency(trans)
                        }
                    },
                    onUpdateCrosshairRotation = { rot ->
                        serviceScope.launch {
                            dataStoreManager.saveCrosshairRotation(rot)
                        }
                    },
                    onPerformRamClean = {
                        serviceScope.launch {
                            val boostResult = RamBooster.performBoost(this@OverlayService)
                            dataStoreManager.saveLastRamFreedMb(boostResult.freedMb)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@OverlayService, boostResult.summary, Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onPerformGameBoost = {
                        serviceScope.launch {
                            val result = GameBooster.performGameBoost(this@OverlayService, currentProfile.packageName)
                            dataStoreManager.setGameBoostActive(result.isSuccess)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@OverlayService, result.message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onToggleMetric = { metricKey ->
                        serviceScope.launch {
                            val cur = when (metricKey) {
                                "fps" -> currentProfile.showFps
                                "frame_time" -> currentProfile.showFrameTime
                                "cpu" -> currentProfile.showCpu
                                "clock" -> currentProfile.showClock
                                "ram" -> currentProfile.showRam
                                "temp" -> currentProfile.showTemp
                                "battery" -> currentProfile.showBattery
                                else -> true
                            }
                            dataStoreManager.updateMetricToggle(metricKey, !cur)
                        }
                    },
                    onToggleGraph = {
                        serviceScope.launch {
                            dataStoreManager.updateMetricToggle("graph", !currentProfile.showGraph)
                        }
                    },
                    onToggleCrosshair = {
                        serviceScope.launch {
                            dataStoreManager.updateMetricToggle("crosshair", !currentProfile.showCrosshair)
                        }
                    },
                    onToggleMacroE = { enabled ->
                        serviceScope.launch {
                            dataStoreManager.setMacroEEnabled(enabled)
                            if (!enabled) MacroTapExecutor.stopMacroE()
                        }
                    },
                    onUpdateMacroESize = { size ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroESize(size)
                        }
                    },
                    onUpdateMacroETransparency = { trans ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroETransparency(trans)
                        }
                    },
                    onUpdateMacroEButtonPos = { x, y ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroEPosition(x, y)
                        }
                    },
                    onUpdateMacroETargetPos = { x, y ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroETarget(x, y)
                        }
                    },
                    onUpdateMacroEInterval = { interval ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroETiming(interval, interval, false)
                        }
                    },
                    onToggleMacroG = { enabled ->
                        serviceScope.launch {
                            dataStoreManager.setMacroGEnabled(enabled)
                            if (!enabled) MacroTapExecutor.stopMacroG()
                        }
                    },
                    onUpdateMacroGSize = { size ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroGSize(size)
                        }
                    },
                    onUpdateMacroGTransparency = { trans ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroGTransparency(trans)
                        }
                    },
                    onUpdateMacroGButtonPos = { x, y ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroGPosition(x, y)
                        }
                    },
                    onUpdateMacroGTargetPos = { x, y ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroGTarget(x, y)
                        }
                    },
                    onUpdateMacroGInterval = { interval ->
                        serviceScope.launch {
                            dataStoreManager.saveMacroGTiming(interval, interval, false)
                        }
                    },
                    onUpdateMenuSize = { size ->
                        serviceScope.launch {
                            dataStoreManager.saveExpandedMenuSize(size)
                        }
                    },
                    onUpdateTransparency = { alpha ->
                        serviceScope.launch {
                            dataStoreManager.saveGlassTransparency(alpha)
                        }
                    },
                    onOpenApp = {
                        val appIntent = Intent(this@OverlayService, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        }
                        startActivity(appIntent)
                    },
                    onCloseOverlay = {
                        performFullCleanupAndStop()
                    }
                )
            }
        }

        overlayView = composeView
        try {
            windowManager.addView(composeView, params)
        } catch (_: Exception) {}
    }

    private fun updateOverlayWindowAttributes(profile: GameProfile) {
        overlayParams?.let { params ->
            overlayView?.let { view ->
                try {
                    windowManager.updateViewLayout(view, params)
                } catch (_: Exception) {}
            }
        }
    }

    private fun updateMarkerOverlay(profile: GameProfile) {
        if (profile.showCrosshair) {
            if (markerView == null) {
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    } else {
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_PHONE
                    },
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.CENTER
                }
                markerParams = params

                val view = ComposeView(this).apply {
                    setViewTreeLifecycleOwner(lifecycleOwner)
                    setViewTreeViewModelStoreOwner(lifecycleOwner)
                    setViewTreeSavedStateRegistryOwner(lifecycleOwner)

                    setContent {
                        val prof = currentProfile
                        ScreenMarkerOverlay(
                            style = prof.crosshairStyle,
                            colorLong = prof.crosshairColor,
                            sizeDp = prof.crosshairSizeDp,
                            transparency = prof.crosshairTransparency,
                            rotation = prof.crosshairRotation,
                            offsetX = prof.crosshairOffsetX,
                            offsetY = prof.crosshairOffsetY,
                            isCalibrating = false,
                            onDragDelta = { dx, dy ->
                                val newX = (prof.crosshairOffsetX + dx.toInt()).coerceIn(-600, 600)
                                val newY = (prof.crosshairOffsetY + dy.toInt()).coerceIn(-600, 600)
                                serviceScope.launch {
                                    dataStoreManager.saveAimMarkerPosition(newX.toFloat(), newY.toFloat())
                                }
                            }
                        )
                    }
                }
                markerView = view
                try {
                    windowManager.addView(view, params)
                } catch (_: Exception) {}
            }
        } else {
            safelyRemoveView(markerView)
            markerView = null
        }
    }

    private fun updateMacroEOverlay(profile: GameProfile) {
        if (profile.macroEEnabled) {
            if (macroEView == null) {
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    } else {
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_PHONE
                    },
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = profile.macroEPosX
                    y = profile.macroEPosY
                }
                macroEParams = params

                val view = ComposeView(this).apply {
                    setViewTreeLifecycleOwner(lifecycleOwner)
                    setViewTreeViewModelStoreOwner(lifecycleOwner)
                    setViewTreeSavedStateRegistryOwner(lifecycleOwner)

                    setContent {
                        val prof = currentProfile
                        val isRunning by MacroTapExecutor.isERunning.collectAsState()

                        MacroOverlayButton(
                            label = "E",
                            sizeDp = prof.macroESizeDp,
                            transparency = prof.macroETransparency,
                            isRunning = isRunning,
                            onPressDown = {
                                // Always fetch dynamic currentProfile to prevent stale coordinates
                                MacroTapExecutor.startMacroE(
                                    profileProvider = { this@OverlayService.currentProfile },
                                    onStatus = { msg ->
                                        // macro loop runs on a background thread → Toast must go to main thread
                                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                                            Toast.makeText(this@OverlayService, msg, Toast.LENGTH_LONG).show()
                                        }
                                    }
                                )
                            },
                            onPressUp = {
                                MacroTapExecutor.stopMacroE()
                            }
                        )
                    }
                }
                macroEView = view
                try {
                    windowManager.addView(view, params)
                } catch (_: Exception) {}
            } else {
                macroEParams?.let { params ->
                    if (params.x != profile.macroEPosX || params.y != profile.macroEPosY) {
                        params.x = profile.macroEPosX
                        params.y = profile.macroEPosY
                        try {
                            windowManager.updateViewLayout(macroEView, params)
                        } catch (_: Exception) {}
                    }
                }
            }
        } else {
            safelyRemoveView(macroEView)
            macroEView = null
            MacroTapExecutor.stopMacroE()
        }
    }

    private fun updateMacroGOverlay(profile: GameProfile) {
        if (profile.macroGEnabled) {
            if (macroGView == null) {
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    } else {
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_PHONE
                    },
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = profile.macroGPosX
                    y = profile.macroGPosY
                }
                macroGParams = params

                val view = ComposeView(this).apply {
                    setViewTreeLifecycleOwner(lifecycleOwner)
                    setViewTreeViewModelStoreOwner(lifecycleOwner)
                    setViewTreeSavedStateRegistryOwner(lifecycleOwner)

                    setContent {
                        val prof = currentProfile
                        val isRunning by MacroTapExecutor.isGRunning.collectAsState()

                        MacroOverlayButton(
                            label = "G",
                            sizeDp = prof.macroGSizeDp,
                            transparency = prof.macroGTransparency,
                            isRunning = isRunning,
                            onPressDown = {
                                // Always fetch dynamic currentProfile to prevent stale coordinates
                                MacroTapExecutor.startMacroG(
                                    profileProvider = { this@OverlayService.currentProfile },
                                    onStatus = { msg ->
                                        // macro loop runs on a background thread → Toast must go to main thread
                                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                                            Toast.makeText(this@OverlayService, msg, Toast.LENGTH_LONG).show()
                                        }
                                    }
                                )
                            },
                            onPressUp = {
                                MacroTapExecutor.stopMacroG()
                            }
                        )
                    }
                }
                macroGView = view
                try {
                    windowManager.addView(view, params)
                } catch (_: Exception) {}
            } else {
                macroGParams?.let { params ->
                    if (params.x != profile.macroGPosX || params.y != profile.macroGPosY) {
                        params.x = profile.macroGPosX
                        params.y = profile.macroGPosY
                        try {
                            windowManager.updateViewLayout(macroGView, params)
                        } catch (_: Exception) {}
                    }
                }
            }
        } else {
            safelyRemoveView(macroGView)
            macroGView = null
            MacroTapExecutor.stopMacroG()
        }
    }

    private fun safelyRemoveView(view: ComposeView?) {
        if (view != null) {
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {}
        }
    }

    /**
     * Restore Display logic:
     * Restores all configured overlay elements to their previous saved position,
     * size, transparency, rotation, color, and visibility state.
     */
    fun restoreAllDisplays() {
        val prof = currentProfile

        overlayParams?.let { params ->
            params.x = prof.overlayPosX
            params.y = prof.overlayPosY
            overlayView?.let {
                try { windowManager.updateViewLayout(it, params) } catch (_: Exception) {}
            }
        }

        updateMarkerOverlay(prof)
        updateMacroEOverlay(prof)
        updateMacroGOverlay(prof)

        Toast.makeText(this, "Restore Display: Overlays synchronized", Toast.LENGTH_SHORT).show()
    }

    /**
     * Requirement 16 & 17:
     * Full cleanup when cancelled/stopped:
     * 1. Stop E and G macros immediately.
     * 2. Cancel macro jobs.
     * 3. Remove all overlay views.
     * 4. Restore original display baseline if modified.
     * 5. Stop service cleanly.
     */
    private fun performFullCleanupAndStop() {
        MacroTapExecutor.cancelAll()

        safelyRemoveView(overlayView)
        overlayView = null

        safelyRemoveView(markerView)
        markerView = null

        safelyRemoveView(macroEView)
        macroEView = null

        safelyRemoveView(macroGView)
        macroGView = null

        // Restore original display/system settings if modified
        serviceScope.launch(Dispatchers.IO) {
            try {
                val backup = displayBackupManager.getBackup()
                if (backup.isValid) {
                    DisplayCommandExecutor.restoreOriginal(backup)
                    AppLogger.i("Restored original phone settings automatically on overlay exit.")
                }
            } catch (e: Exception) {
                AppLogger.e("Failed to restore display settings: ${e.message}", e)
            }
            withContext(Dispatchers.Main) {
                stopSelf()
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SRT X CHEATS Monitor",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground gaming telemetry & transparent overlay"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundNotification() {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SRT X CHEATS")
            .setContentText("Gaming monitor is active")
            .setSmallIcon(R.drawable.logo_srt)
            .setContentIntent(openPendingIntent)
            .addAction(R.drawable.logo_srt, "STOP", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        MacroTapExecutor.cancelAll()

        safelyRemoveView(overlayView)
        overlayView = null

        safelyRemoveView(markerView)
        markerView = null

        safelyRemoveView(macroEView)
        macroEView = null

        safelyRemoveView(macroGView)
        macroGView = null

        performanceMonitor.stopMonitoring()
        lifecycleOwner.onDestroy()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
