package com.srtxcheats

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.srtxcheats.core.MacroTapExecutor
import com.srtxcheats.model.DeviceMetrics
import com.srtxcheats.model.GameProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SrtxRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("SRT X CHEATS", appName)
  }

  @Test
  fun `verify game profile defaults`() {
    val profile = GameProfile.defaultFor(
      GameProfile.FREE_FIRE_MAX_PACKAGE,
      "Free Fire MAX"
    )
    assertEquals("Free Fire MAX", profile.appName)
    assertEquals("com.dts.freefiremax", profile.packageName)
    assertEquals(true, profile.showFps)
    assertEquals(true, profile.isOverlayEnabled)
    assertEquals(true, profile.showCpu)
    assertEquals(true, profile.showRam)
    assertEquals(false, profile.showCrosshair)
  }

  @Test
  fun `verify device metrics display formatting`() {
    val metrics = DeviceMetrics(
      fps = 60,
      displayHz = 120,
      cpuUsagePercent = 42,
      cpuClockGhz = 2.45f,
      ramUsedGb = 4.2f,
      ramTotalGb = 8.0f,
      batteryTempC = 36.5f
    )
    assertEquals("60", metrics.fpsDisplay)
    assertEquals("42%", metrics.cpuUsageDisplay)
    assertEquals("2.45 GHz", metrics.cpuClockDisplay)
    assertEquals("36.5°C", metrics.batteryTempDisplay)
  }

  @Test
  fun `verify gaming mode and performance boost default states`() {
    val profile = GameProfile.defaultFor("com.dts.freefiremax", "Free Fire MAX")
    assertEquals(false, profile.isGamingModeActive)
    assertEquals(false, profile.isPerformanceBoostActive)
    assertEquals(true, profile.isRamBoostActive)
  }

  @Test
  fun `verify crosshair visual styles and presets`() {
    val profile = GameProfile.defaultFor("com.dts.freefiremax", "Free Fire MAX")
    assertEquals("CROSS", profile.crosshairStyle)
    assertEquals(0xFF00E5FF, profile.crosshairColor)
    assertEquals(24, profile.crosshairSizeDp)
    assertEquals(1.0f, profile.crosshairTransparency)
    assertEquals(0f, profile.crosshairRotation)
    assertEquals(15, com.srtxcheats.ui.overlay.AimCursorRenderer.STYLES.size)
  }

  @Test
  fun `verify restore display default state`() {
    val profile = GameProfile.defaultFor("com.dts.freefiremax", "Free Fire MAX")
    assertEquals(true, profile.restoreDisplayEnabled)
  }

  @Test
  fun `verify macro E and G are independently configured`() {
    val profile = GameProfile.defaultFor("com.dts.freefiremax", "Free Fire MAX")
    assertEquals(false, profile.macroEEnabled)
    assertEquals(false, profile.macroGEnabled)
    assertEquals(48, profile.macroESizeDp)
    assertEquals(56, profile.macroGSizeDp)
    assertEquals(120, profile.macroEPosX)
    assertEquals(400, profile.macroEPosY)
    assertEquals(540, profile.macroETargetX)
    assertEquals(960, profile.macroETargetY)
    assertEquals(120, profile.macroGPosX)
    assertEquals(520, profile.macroGPosY)
    assertEquals(540, profile.macroGTargetX)
    assertEquals(1100, profile.macroGTargetY)
    assertEquals(100, profile.macroETapSpeedMs)
    assertEquals(100, profile.macroERetapSpeedMs)
    assertEquals(100, profile.macroGTapSpeedMs)
    assertEquals(100, profile.macroGRetapSpeedMs)
    assertEquals(false, profile.macroELoop)
    assertEquals(false, profile.macroGLoop)
  }

  @Test
  fun `verify macro E execution lifecycle and cancellation`() {
    val profile = GameProfile.defaultFor("com.dts.freefiremax", "Free Fire MAX")
    MacroTapExecutor.startMacroE(profile)
    MacroTapExecutor.stopMacroE()
    assertFalse(MacroTapExecutor.isERunning.value)
    MacroTapExecutor.startMacroG(profile)
    MacroTapExecutor.stopMacroG()
    assertFalse(MacroTapExecutor.isGRunning.value)
    MacroTapExecutor.cancelAll()
  }

  @Test
  fun `verify ram calculation percentage`() {
    val metrics = DeviceMetrics(
      ramUsedGb = 4.0f,
      ramTotalGb = 8.0f
    )
    assertEquals(50, metrics.ramPercent)
  }
}
